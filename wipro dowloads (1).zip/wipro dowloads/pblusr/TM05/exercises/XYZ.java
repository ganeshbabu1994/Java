class XYZ implements Cloneable 
{
	
	String a;
	int b;
	XYZ(String x,int y)
	{
		a=x;
		b=y;
	}

	XYZ cloneTest()throws  CloneNotSupportedException
	
		{
		
			return (new XYZ(a,b));
		
	}
}