class CloneDemo1 
{
	public static void main(String args[]) throws CloneNotSupportedException
	{
	
		XYZ x1= new XYZ("ganesh",12214);
		XYZ x3=new XYZ("ramesh",12214);
		XYZ x2;
		x2=x1.cloneTest();
		System.out.println("x1 : " + x1.a + " " + x1.b);
		System.out.println("x2 : " + x2.a + " " + x2.b);
		x2 = x3.cloneTest(); // cloning x1
		System.out.println("x1 : " + x3.a + " " + x3.b);
		System.out.println("x2 : " + x2.a + " " + x2.b);
		}
	}
