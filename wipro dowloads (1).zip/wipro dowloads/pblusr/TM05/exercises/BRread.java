import java.io.*;
import java.util.*;
public class BRread {
	public static void main(String args[]) throws IOException
	{
	BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
	char a = '\0';
	Scanner s=new Scanner(System.in);
	do
	{
		a=(char) b.read();
		System.out.print(a);
	}while(a!='g');
	
	}

}
