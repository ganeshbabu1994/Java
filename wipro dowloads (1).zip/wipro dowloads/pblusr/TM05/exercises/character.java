import java.io.*;
import java.lang.*;
import java.util.*;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileWriter;

public class character {
public static void main(String args[]) throws IOException
{
File input=new File("source.txt");
FileReader in=new FileReader(input);
int c;
char a;
int count=0;
do
{
	c=in.read();
	a=(char)c;
	if(a==args[0].charAt(0))
	{
	count++;
	}
}while(c!=-1);
System.out.println(count);
in.close();

}

}


