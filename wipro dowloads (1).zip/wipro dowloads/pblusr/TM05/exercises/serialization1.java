import java.io.*;


public class serialization1 {
public static void main(String aggs[]) throws IOException
{
	
	try
	{
	FileOutputStream out=new FileOutputStream("source.txt");
	ObjectOutputStream obj1=new ObjectOutputStream(out);
	obj1.writeObject("hello");
	//obj1.writeObject(new Date());
	obj1.flush();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}
}


