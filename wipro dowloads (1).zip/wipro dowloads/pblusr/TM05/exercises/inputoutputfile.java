import java.io.*;
import java.util.*;


public class inputoutputfile {
	public static void main(String args[]) throws IOException
	{
		File input=new File("input.txt");
		File output=new File("output.txt");
		FileReader i=new FileReader(input);
		FileWriter o=new FileWriter(output);
		Scanner in=new Scanner(System.in);
		
		int m,n;
		char a;
		 a=in.next().charAt(0);                                                            
		do
		{
			
			m=i.read();
		o.write(m);
		}while(m!=-1);
		i.close();
		o.close();
		
	}

}
