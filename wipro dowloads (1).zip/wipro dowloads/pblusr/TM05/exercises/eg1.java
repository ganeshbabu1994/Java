import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class eg1{
	public static void main(String args[]) throws IOException
	{
		File input=new File("hai.txt");
		File output=new File("a.txt");
		FileReader in=new FileReader(input);
		FileWriter out=new FileWriter(output);
		int m,count=0;
		char c;
	while((m=in.read())!=-1)
		{
			m=in.read();
			c=(char)m;
		out.write(m);
		if(c==args[0].charAt(0))
		{
			count++;
		}
	if(in!=null)
	 in.close();
	if(out!=null)
	 out.close();
	System.out.println(count);
		}
}
}