
import java.io.*;
import java.util.*;
public class blockconsole 
{
public static void main(String args[]) throws IOException
{
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
BufferedWriter b=new BufferedWriter(new FileWriter("hai.txt",true));
String input=" ";
do
{
	input=br.readLine();
	b.write(input);
	b.newLine();
}while(!input.equals("ganesh"));
br.close();
b.close();
}
}
