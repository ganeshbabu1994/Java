public class boxtest 
{
	void m1(Integer i1) 
	{
		System.out.println("intvalue=" +i1);
		}
	public static void main(String a[]) 
	{
		boxtest t = new boxtest();
		Integer i1=10;
		t.m1(i1);
		}
	}
