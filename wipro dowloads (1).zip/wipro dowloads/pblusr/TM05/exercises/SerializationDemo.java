import java.io.*;

class MyClass implements Serializable {
	
	String s;
	int i;
	double d;
	
	MyClass(String s, int i, double d) {
		this.s = s;
		this.i = i;
		this.d = d;
	}
	
	public String toString() {
		return "s="+s+";i="+i+";d="+d;
	}
}

public class SerializationDemo {
	public static void main(String args[]) {
		try {
			MyClass Obj = new MyClass("Ganesh", 10, 20.00);
			System.out.println(Obj);
			FileOutputStream fos = new FileOutputStream("Serial");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(oos);
			oos.flush();
			oos.close();
		}
		catch(Exception e) {
			System.out.println("Exception During Serialization:" +e);
			System.exit(0);
		}
	}
}
