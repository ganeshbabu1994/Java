import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.*;
public class filemain {

	public static void main (String args[ ]) throws IOException {
	File input=new File("hello.txt");
	File output=new File("a.txt");
	FileReader inreader=new FileReader(input);
	FileWriter outreader=new FileWriter(output);
	BufferedReader bread=new BufferedReader(inreader);
	BufferedWriter bwrite=new BufferedWriter(outreader);
	int c;
	do {
	c =  inreader.read( );
	outreader.write(c);
	}while (c!=-1);
	//String str;
/*	while((str=bread.readLine())!=null){
	
		outreader.write(bwrite.write(str));
	}*/
	
	
	inreader.close();
	outreader.close();
	}
	}