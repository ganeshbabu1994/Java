import java.io.*;
import java.lang.*;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileWriter;

public class endfile {
public static void main(String args[]) throws IOException
{
File input=new File("source.txt");
File output=new File("destination.txt");
FileReader in=new FileReader(input);
FileWriter o=new FileWriter(output);
int c;
do
{
	c=in.read();
	o.write(c);
	

}while(c!=-1);
in.close();
o.close();
}
}
