import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;


public class deserialization {
	private static final String Date = null;
	private static String date;

	public static void main(String args[])
	{
		try
		{
		
		
		FileOutputStream out=new FileOutputStream("source.txt");
		ObjectOutputStream obj1=new ObjectOutputStream(out);
		obj1.writeObject("hello");
		obj1.writeObject(new Date(date));
		obj1.flush();
		
		FileInputStream in=new FileInputStream("hai.txt");
		ObjectInputStream obj2=new ObjectInputStream(in);
		String s1=(String)obj2.readObject();
		Date date=(Date)obj2.readObject();
		obj2.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	}


