import java.io.*;
import java.lang.*;
import java.util.*;
 class stringcount {
public static void main(String args[]) throws IOException
{
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
//File input=new File("source.txt");
//FileReader in=new FileReader(input);
BufferedWriter b = new BufferedWriter(new FileWriter("hai.txt"));
String c;
char a;
String s1;
int count=0;
String str=br.readLine();
String s[]=str.split(" ");
int len=s.length;
do
{

//	a=(char)c;
	
	for(int i=0;i<=len;i++)
	{
		for(int j=len;j>00;j--)
		{
		if(s[i].equals(s[j]))
			{
		count++;
			}
		}
	}
	
}while(!str.equals("a"));
System.out.println("sucess");
System.out.println(count);
b.write(count);
br.close();
//in.close();
}

}



