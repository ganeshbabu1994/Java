public class boxclass
{
	void m1(Float i1) 
	{
		System.out.println("intvalue=" +i1);
		}
	void m1(float i1) 
	{
		System.out.println("float value=" +i1);
		}
	public static void main(String a[]) 
	{
		boxclass t = new boxclass();
		float i=12.0f;
		
		t.m1(i);
		t.m1(5);
		}
	}

