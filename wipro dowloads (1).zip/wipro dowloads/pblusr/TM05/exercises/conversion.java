
public class conversion {
	public static void main(String args[])
	{
	int a=Integer.parseInt(args[0]);
	System.out.println(Integer.toBinaryString(a));
	System.out.println(Integer.toHexString(a));
	System.out.println(Integer.toOctalString(a));
	
	}

}
