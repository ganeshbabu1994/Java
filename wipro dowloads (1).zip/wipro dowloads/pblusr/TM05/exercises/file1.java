import java.io.*;


public class file1 {
public static void main(String args[]) throws IOException
{
File input=new File("source.txt");
File output=new File("destination.txt");
FileReader in=new FileReader(input);
FileWriter o=new FileWriter(output);
int c;

while((in.read())!=-1)
{
	c=in.read();
	o.write(c);

}
in.close();
o.close();
}
}
