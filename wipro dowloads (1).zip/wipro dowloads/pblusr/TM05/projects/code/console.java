import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;
import java.io.*;


public class console {
	public static void main(String args[]) throws IOException
	{
		Scanner in=new Scanner(System.in);
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		System.out.println("main menu");
		System.out.println("1. Add an Employee \n2. Display All \n3. Exit ");
		System.out.println("Name");
		System.out.println("Id");
		System.out.println("Designation");
		System.out.println("Salary");
		File file=new File("employee.txt");
		int a=in.nextInt();
		String str;
		int id;
		switch(a)
		{
		case 1:
			str=in.nextLine();
			
			id=in.nextInt();
			
			String des=in.nextLine();
		
			int salary=in.nextInt();
			
			FileWriter w=new FileWriter(file);
			w.write(str);
			w.write(id);
			w.write(des);
			w.write(salary);
		
			
		}
		
	}



}
