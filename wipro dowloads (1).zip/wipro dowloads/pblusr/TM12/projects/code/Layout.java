package swing;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.*;

public class Layout extends JFrame{
public	Layout1(String s){
	setTitle(s);
	}
	public static void main(String args[]){
		JFrame f=new Layout1("my_Layout");
		
		f.setSize(200,200);
		f.setVisible(true);
	
		JPanel jp=new JPanel();
		
	
		
		jp.add(new JLabel("Name"));
		jp.add(new JTextField(20));
		jp.add(new JLabel("Gender"));
		
		
		JRadioButton rb1=new JRadioButton("Male");
		JRadioButton rb2=new JRadioButton("Female");
		ButtonGroup bgp=new ButtonGroup();
		bgp.add(rb1);
		bgp.add(rb2);
		jp.add(rb1);
		jp.add(rb2);
		jp.add(new JButton("submit"));
		
	f.getContentPane().add(jp);
		
	}
	

}
