package swing;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;

public class Calculation extends JFrame implements ActionListener{
	public int i;
	public 	JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b0,badd,bmin,bmul,bdiv,bc,bexit,bequal;
	JTextField t=new JTextField();
	  JFrame f=new JFrame();
	   JPanel jp=new JPanel();

	
	Calculation(){
	t=new JTextField(30);
		 		   jp.add(t);
		
		   f.setSize(350,300);
			f.setVisible(true);
			b1=new JButton("1");
			b2=new JButton("2");
			b3=new JButton("3");
			b4=new JButton("4");
			b5=new JButton("5");
			b6=new JButton("6");
			b7=new JButton("7");
			b8=new JButton("8");
			b9=new JButton("9");
			b0=new JButton("0");
			badd=new JButton("+");
			bmin=new JButton("-");
			bmul=new JButton("*");
			bdiv=new JButton("/");
			bc=new JButton("C");
					bexit=new JButton("exit");
					bequal=new JButton("=");
			
			jp.add(b1);
			jp.add(b2);
			jp.add(b3);
			jp.add(b4);
			jp.add(b5);
			jp.add(b6);
			jp.add(b7);
			jp.add(b8);
			jp.add(b9);
			jp.add(b0);
			jp.add(badd);
			jp.add(bmin);
			jp.add(bmul);
			jp.add(bdiv);
			jp.add(bc);
			
			jp.add(bequal);
			jp.add(bexit);
			
			b1.addActionListener(this);
			b2.addActionListener(this);
			b3.addActionListener(this);

			b4.addActionListener(this);

			b5.addActionListener(this);

			b6.addActionListener(this);

			b7.addActionListener(this);

			b8.addActionListener(this);

			b9.addActionListener(this);

			b0.addActionListener(this);

			badd.addActionListener(this);

			bmin.addActionListener(this);

			bmul.addActionListener(this);

			bdiv.addActionListener(this);

			bc.addActionListener(this);

			bexit.addActionListener(this);

			bequal.addActionListener(this);

			
			   f.getContentPane().add(jp);
			   f.setVisible(true);
	  
		
	}
	   public static void main(String[] args) {
		   Calculation c=new Calculation();
		   
		 }

	@Override
	public void actionPerformed(ActionEvent e) {
		int choice=0 ;
		double a = 0 ,b,result=0;
		 if(e.getSource()==b1)
	            t.setText(t.getText().concat("1"));
	        
	        if(e.getSource()==b2)
	            t.setText(t.getText().concat("2"));
	        
	        if(e.getSource()==b3)
	            t.setText(t.getText().concat("3"));
	        
	        if(e.getSource()==b4)
	            t.setText(t.getText().concat("4"));
	        
	        if(e.getSource()==b5)
	            t.setText(t.getText().concat("5"));
	        
	        if(e.getSource()==b6)
	            t.setText(t.getText().concat("6"));
	        
	        if(e.getSource()==b7)
	            t.setText(t.getText().concat("7"));
	        
	        if(e.getSource()==b8)
	            t.setText(t.getText().concat("8"));
	        
	        if(e.getSource()==b9)
	            t.setText(t.getText().concat("9"));
	        
	        if(e.getSource()==b0)
	            t.setText(t.getText().concat("0"));
	        
	        if(e.getSource()==bc)
	            t.setText(" ");
	        
	        if(e.getSource()==badd)
	        {
	            a=Double.parseDouble(t.getText());
	            System.out.println(a);
	            choice=1;
	            t.setText("");
	        } 
	        
	        if(e.getSource()==bmin)
	        {
	            a=Double.parseDouble(t.getText());
	            choice=2;
	            t.setText("");
	        }
	        
	        if(e.getSource()==bmul)
	        {
	            a=Double.parseDouble(t.getText());
	            choice=3;
	            t.setText("");
	        }
	        
	        if(e.getSource()==bdiv)
	        {
	            a=Double.parseDouble(t.getText());
	            choice=4;
	            t.setText("");
	        }
	        
	        if(e.getSource()==bequal)
	        {
	            b=Double.parseDouble(t.getText());
	        
	            switch(choice)
	            {
	                case 1: result=a+b;
	                    break;
	        
	                case 2: result=a-b;
	                    break;
	        
	                case 3: result=a*b;
	                    break;
	        
	                case 4: result=a/b;
	                    break;
	        
	                default: result=0;
	            }
	        
	            t.setText(""+result);
	        }
	        if (e.getSource()==bexit){
	        	f.dispose();


	        }
	        
	    }
}

		
		
	


