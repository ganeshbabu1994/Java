package swing;

import java.awt.Dimension;

import javax.swing.*;

public class list {
	DefaultListModel lm = new DefaultListModel();
public 	 void addExtraItem(String str, int pos) {
		 
		lm.add(pos,str); 
	 }
	 jlist(){
			
			JFrame f=new Layout1("my_Layout");
				
				f.setSize(300,300);
				f.setVisible(true);
			
				JPanel jp=new JPanel();
			
				
			lm.addElement("one");
			lm.addElement("two");
			lm.addElement("three");
			lm.addElement("four");
			lm.addElement("five");
			  JList<String> jl = new JList<String>(lm);
			
			jl.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			jl.setFixedCellHeight(12);
			    jl.setFixedCellWidth(200);
				JScrollPane js=new JScrollPane(jl);
		
				

				jl.setVisibleRowCount(4);
				jp.add(js);
				f.getContentPane().add(jp);

				 f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 
	 }
	public static void main(String args[])
	{
		jlist j=new jlist();
		j.addExtraItem("im second",0);
	}
	}

