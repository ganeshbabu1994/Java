package swing;

import java.awt.*;

import org.jdatepicker.impl.*;
import javax.swing.*;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.text.DateFormatter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


public class project1 extends JFrame
{




public static void main(String args[])
{
	JFrame f=new JFrame();
	f.setVisible(true);
	f.setSize(300, 300);
	JLabel j1,j2,j3,j4,j5,j6,j7,j8,j9,j10,j11,j12,js;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
	JPasswordField p1=new JPasswordField(10);
	JPasswordField p2=new JPasswordField(10);
	j1=new JLabel("First name");
	j2=new JLabel("Last name");
	j3=new JLabel("DOB");
	js=new JLabel(" ");
	j4=new JLabel("Gender");
	js=new JLabel(" ");
	j5=new JLabel("Street");
	j6=new JLabel("City");
	j7=new JLabel("State");
	j8=new JLabel("Pincode");
	j9=new JLabel("mobile number");
	j10=new JLabel("EmailId");
	j11=new JLabel("password");
	j12=new JLabel("confirm password");
	

	UtilDateModel model = new UtilDateModel();
	Properties p = new Properties();
	p.put("text.today", "Today");
	p.put("text.month", "Month");
	p.put("text.year", "Year");
	JDatePanelImpl datePanel = new JDatePanelImpl(model,p);
	
	
	JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());
	
	
	t1=new JTextField();
	t2=new JTextField();
	t3=new JTextField();
	t4=new JTextField();
	t5=new JTextField();
	t6=new JTextField();
	t7=new JTextField();
	t8=new JTextField();
	t9=new JPasswordField(10);
	t10=new JPasswordField(10);



	


	   JRadioButton r1=new JRadioButton("Male",true);
		JRadioButton r2=new JRadioButton("Female");
		ButtonGroup g =new ButtonGroup();
		f.getContentPane().setLayout(new GridLayout(13,2));
		g.add(r1);
		g.add(r2);
		f.getContentPane().add(r1);
		f.getContentPane().add(r2);
		
		//f.add(Calendar,r3);
		
	//r1.setBounds(80, 315, 200, 30);
	//r2.set 
	f.add(j1);
	f.add(t1);
	f.add(j2);
	f.add(t2);
	f.add(j3);
	f.add(datePicker);
	f.add(j4);
	f.add(r1);
	
	f.add(new JLabel(""));
	f.add(r2);
	f.add(j5);
	f.add(t3);
	f.add(j6);
	f.add(t4);
	f.add(j7);
	f.add(t5);
	f.add(j8);
	f.add(t6);
	f.add(j9);
	f.add(t7);
	f.add(j10);
	f.add(t8);
	f.add(j11);
	f.add(t9);
	f.add(j12);
	
	f.add(t10);
	
	
	
	
	
}	
	

}


class DateLabelFormatter extends AbstractFormatter {

    private String datePattern = "yyyy-MM-dd";
    private SimpleDateFormat dateFormatter = new SimpleDateFormat(datePattern);

    @Override
    public Object stringToValue(String text) throws ParseException 
    {
        return dateFormatter.parseObject(text);
    }

    @Override
    public String valueToString(Object value) throws ParseException 
    {
        if (value != null) 
        {
            Calendar cal = (Calendar) value;
            return dateFormatter.format(cal.getTime());
        }

        return "";
    }
}

