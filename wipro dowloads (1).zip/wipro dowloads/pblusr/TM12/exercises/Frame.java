package swingPrograms;

import javax.swing.*;

import java.awt.*;
	public class Frame5 extends JFrame {
		public Frame(String str)
		{
			setTitle(str);
		}
		public static void main(String args[])
		{
			JFrame obj=new JFrame("Frame5");
			obj.setSize(500,500);
			obj.setLocation(100,100);
			obj.setVisible(true);
			JPanel jpan=new JPanel();
			jpan.setLayout(null);
			JComboBox com=new JComboBox();
			com.addItem("EEE");
			com.addItem("ECE");
			com.addItem("IT");
			com.addItem("CSE");
			com.addItem("ETE");
			com.setBounds(10, 10, 150, 25);
			int i=com.getItemCount();
			JLabel l=new JLabel("There are " +i+ " items in a combobox");
			l.setBounds(10, 50, 700, 25);
			jpan.add(com);
			jpan.add(l);
			obj.getContentPane().add(jpan);
			

}
	}
