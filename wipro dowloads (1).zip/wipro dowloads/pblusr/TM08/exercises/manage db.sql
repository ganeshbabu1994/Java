1)
alter table EMP ADD(salary number(7)default 500  not null );

2)
alter table EMP read only ;table EMP altered.

3)
alter table EMP read write ;

4)
create table MyDept as select * from Dept where 1=1;

5)
flashback table MyDEpt to before drop;

6)
drop table MYDEPt purge;
