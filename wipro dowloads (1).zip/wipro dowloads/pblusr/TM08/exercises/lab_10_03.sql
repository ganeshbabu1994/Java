CREATE TABLE EMP(ID NUMBER(7) primary key,LAST_NAME varchar2(25) not null ,FIRST_NAME  varchar2(25),
Deptartment_id number(7) ,foreign key(Deptartment_id) references DEPT(dept_id));

insert into EMP values(101,'Sam','Sundar',10);
insert into EMP values(101,'Ram','Krishna',20);
insert into EMP values(102,'Gopi','null',40);
insert into EMP values(103,'null','ram',20);