1)

select max(salary),min(salary),sum(salary),avg(salary) from employees;


2).
select manager_id,min(salary) from employees having manager_id id not null and min(salary)<=6000 group by manager_id order by min(salary) desc;