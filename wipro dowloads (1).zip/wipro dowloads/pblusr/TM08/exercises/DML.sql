1.
table MY_EMPLOYEE created.

2.
desc MY_EMPLOYEE;

3.
1 rows inserted.

4.
1 rows inserted.

5.
1 rows inserted.

6.
old:insert into MY_EMPLOYEE values('&Enter_Emp_No', '&enter_fname', '&enter_lname', '&enter_dept_no','&enter_salary')
new:insert into MY_EMPLOYEE values('204', 'Hermannn', 'Baer', '70','10000')
1 rows inserted.

7.
old:insert into MY_EMPLOYEE values('&Enter_Emp_No', '&enter_fname', '&enter_lname', '&enter_dept_no','&enter_salary')
new:insert into MY_EMPLOYEE values('204', 'Hermannn', 'Baer', '70','10000')
1 rows inserted.
old:insert into MY_EMPLOYEE values('&Enter_Emp_No', '&enter_fname', '&enter_lname', '&enter_dept_no','&enter_salary')
new:insert into MY_EMPLOYEE values('205', 'Shelley', 'Higgins', '110','12000')
1 rows inserted.
old:insert into MY_EMPLOYEE values('&Enter_Emp_No', '&enter_fname', '&enter_lname', '&enter_dept_no','&enter_salary')
new:insert into MY_EMPLOYEE values('100', 'Steven', 'King', '90','24000')
1 rows inserted.
old:insert into MY_EMPLOYEE values('&Enter_Emp_No', '&enter_fname', '&enter_lname', '&enter_dept_no','&enter_salary')
new:insert into MY_EMPLOYEE values('101', 'Neena', 'Kochhar', '90','17000')
1 rows inserted.
old:insert into MY_EMPLOYEE values('&Enter_Emp_No', '&enter_fname', '&enter_lname', '&enter_dept_no','&enter_salary')
new:insert into MY_EMPLOYEE values('102', 'Lex De', 'Haan', '90','17000')
1 rows inserted.
old:insert into MY_EMPLOYEE values('&Enter_Emp_No', '&enter_fname', '&enter_lname', '&enter_dept_no','&enter_salary')
new:insert into MY_EMPLOYEE values('111', 'Ismael', 'Sciarra', '100','7700')
1 rows inserted.
old:insert into MY_EMPLOYEE values('&Enter_Emp_No', '&enter_fname', '&enter_lname', '&enter_dept_no','&enter_salary')
new:insert into MY_EMPLOYEE values('112', 'Jose Manuel Urman', '100', '7800','null')


8.
update MY_EMPLOYEE set salary=(salary+salary*.01) where department_id = 90;

3 rows updated.

9.
update MY_EMPLOYEE set last_name='Higgins' where employee_id = 202;
0 rows updated.

10.
update MY_EMPLOYEE set department_id=70, salary=(salary+salary*.02) where employee_id = 100;
1 rows updated.

11.
delete from MY_EMPLOYEE where first_name='%man%' or last_name='%man%';
0 rows deleted.
