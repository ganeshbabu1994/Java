1)
select employee_id,last_name,salary,ROUND(salary+(salary*0.155)) "new salary"from EMPLOYEES;

2)
select LOWER(substr(last_name,0,1))||upper(substr(last_name,2,length(last_name)))"Last name",LENGTH(last_name) "LENGTH" from EMPLOYEES where last_name like 'J%' or 
last_name like 'A%' or last_name like 'M%' order by length(last_name);


3)
select last_name, ROUND(months_between(sysdate,hire_date)) MONTHS_WORKED from employees  order by MONTHS_WORKED ;






4)
select last_name,lpad(salary,15,'$') SALARY from employees;





5)

select substr(last_name,1,8) EMPLOYEES ,lpad('*',(salary/1000),'*') SALARIES from employees order by salary desc ;

