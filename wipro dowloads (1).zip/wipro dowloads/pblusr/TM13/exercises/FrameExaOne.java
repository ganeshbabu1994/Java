package swing;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
public class FrameExaOne extends JFrame implements ActionListener{
	
	
	JButton b1;
	JTextField t1,t2,t3;
	Container con;
	Connection con1;
	PreparedStatement pst;
	
	
	public FrameExaOne()
	{
		setLayout(new FlowLayout());
		con=getContentPane();
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
			
			
			
		}catch(Exception ex){ex.printStackTrace();}
		
		b1=new JButton("Add");
		t1=new JTextField(10);
		t2=new JTextField(10);
		t3=new JTextField(10);
		con.add(b1);
		con.add(t1);
		con.add(t2);
		con.add(t3);
		b1.addActionListener(this);
		
		
		
		
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==b1)
		{
			try
			{
			int s1=Integer.parseInt(t1.getText());
			String s2=t2.getText();
			int s3=Integer.parseInt(t3.getText());
			pst=con1.prepareStatement("insert into students values(?,?,?)");
			pst.setInt(1, s1);
			pst.setString(2, s2);
			pst.setInt(3, s3);
			int a=pst.executeUpdate();
			t1.setText("");
			t2.setText("");
			t3.setText("");
			if(a==1)
			{
				JOptionPane.showMessageDialog(null, "Record Inserted");
			}
			
			
			}catch(Exception ex){ex.printStackTrace();}
			
			
						
			
		}
		
	}

	public static void main(String[] args) {
		
		FrameExaOne obj=new FrameExaOne();
		obj.setSize(200, 200);
		obj.setVisible(true);
		obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}

}
