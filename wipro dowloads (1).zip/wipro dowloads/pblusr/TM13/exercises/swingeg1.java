package swing;
import java.applet.*;

import javax.swing.*;

public class swingeg1 extends JFrame {
	public String title;
	swingeg1(String heading)
	{
		title=heading;
	}
	public static void main(String args[])
	{
		JFrame f=new swingeg1("Swingtitle");
		
		f.setSize(100,100);
		f.setLocation(100, 100);
		f.setVisible(true);
		JButton b=new JButton();
		b.setActionCommand("click");
		b.setEnabled(true);
		b.addActionListener(null);
		b.setToolTipText("click to proceed");
	JPanel my=new JPanel();
	my.add(new JLabel("wipro"));
	my.add(new JLabel("Technologies"));
	my.add(b);
	f.getContentPane().add(my);
	}
	

}
