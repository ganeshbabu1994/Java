import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
 

 public class Mouse extends JFrame implements MouseListener{
       
        int x=0,y=0;
        String str = "";
       
    Mouse(){
                
    		
    	         setLayout(new FlowLayout());	
    			 setTitle("Window With Mouse Events");
                 addMouseListener(this);
                 setSize(300,300);
                 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                 setVisible(true);
        }
       
       
 
        public void mouseClicked(MouseEvent e) {
               
           
        		str = "Mouse Clicked at ";
                x = e.getX();
                y = e.getY();
                repaint();
        }
 
 
        public void mousePressed(MouseEvent e) {
              
        }
 
 
        public void mouseReleased(MouseEvent e) {
               
 
        }
 
 
        public void mouseEntered(MouseEvent e) {
            
 
        }
 
 
        public void mouseExited(MouseEvent e) {
             
 
        }
       
       
        public void paint(Graphics g){
        		if(x!=0 && y!=0)
        		g.drawString(str + x + "," + y,80,80);
        		
        }
       
        public static void main(String[] args) {
               
           new Mouse();
        
        }
}
