//package swing;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;

public class Calc extends JFrame implements ActionListener{
	public int i;
	public 	JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b0,badd,bmin,bmul,bdiv,bc,bexit,bequal,bsin,bcos,btan,bcosec,bcot,bsec,bsq,blog;
	JTextField t=new JTextField();
	  JFrame f=new JFrame();
	   JPanel jp=new JPanel();
	   String choice = null ;
	   String choice1 = null ;

		//double a = 0 ,b,
		double result = 0;
		double h = 0,l = 0;

	
	Calculator(){
	t=new JTextField(30);
		 		   jp.add(t);
		
		   f.setSize(350,300);
			f.setVisible(true);
			b1=new JButton("1");
			b2=new JButton("2");
			b3=new JButton("3");
			b4=new JButton("4");
			b5=new JButton("5");
			b6=new JButton("6");
			b7=new JButton("7");
			b8=new JButton("8");
			b9=new JButton("9");
			b0=new JButton("0");
			badd=new JButton("+");
			bmin=new JButton("-");
			bmul=new JButton("*");
			bdiv=new JButton("/");
			bc=new JButton("C");
					bexit=new JButton("exit");
					bequal=new JButton("=");
			bsin=new JButton("sin");
			bcos=new JButton("cos");
			btan=new JButton("tan");
			bsec=new JButton("sec");

			bcosec=new JButton("cosec");
			bcot=new JButton("cot");
			bsq=new JButton("x^x");
blog=new JButton("log10");
jp.add(blog);
jp.add(bsq);
jp.add(bsin);
jp.add(bcot);
jp.add(btan);
jp.add(bcosec);
jp.add(bsec);
jp.add(bcos);

			jp.add(b1);
			jp.add(b2);
			jp.add(b3);
			jp.add(b4);
			jp.add(b5);
			jp.add(b6);
			jp.add(b7);
			jp.add(b8);
			jp.add(b9);
			jp.add(b0);
			jp.add(badd);
			jp.add(bmin);
			jp.add(bmul);
			jp.add(bdiv);
			jp.add(bc);
			
			jp.add(bequal);
			jp.add(bexit);
			
			b1.addActionListener(this);
			b2.addActionListener(this);
			b3.addActionListener(this);

			b4.addActionListener(this);

			b5.addActionListener(this);

			b6.addActionListener(this);

			b7.addActionListener(this);

			b8.addActionListener(this);

			b9.addActionListener(this);

			b0.addActionListener(this);

			badd.addActionListener(this);

			bmin.addActionListener(this);

			bmul.addActionListener(this);

			bdiv.addActionListener(this);

			bc.addActionListener(this);

			bexit.addActionListener(this);

			bequal.addActionListener(this);
			bsin.addActionListener(this);
			bsec.addActionListener(this);
			bcosec.addActionListener(this);
			bcos.addActionListener(this);
			btan.addActionListener(this);
			bcot.addActionListener(this);
			bsq.addActionListener(this);
			blog.addActionListener(this);

			
			   f.getContentPane().add(jp);
			   f.setVisible(true);
	  
		
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		
		 if(e.getSource()==b1)
	            t.setText(t.getText().concat("1"));
	        
	        if(e.getSource()==b2)
	            t.setText(t.getText().concat("2"));
	        
	        if(e.getSource()==b3)
	            t.setText(t.getText().concat("3"));
	        
	        if(e.getSource()==b4)
	            t.setText(t.getText().concat("4"));
	        
	        if(e.getSource()==b5)
	            t.setText(t.getText().concat("5"));
	        
	        if(e.getSource()==b6)
	            t.setText(t.getText().concat("6"));
	        
	        if(e.getSource()==b7)
	            t.setText(t.getText().concat("7"));
	        
	        if(e.getSource()==b8)
	            t.setText(t.getText().concat("8"));
	        
	        if(e.getSource()==b9)
	            t.setText(t.getText().concat("9"));
	        
	        if(e.getSource()==b0)
	            t.setText(t.getText().concat("0"));
	        
	        //if(e.getSource()==bc)
	          //  t.setText(" ");
	        if(e.getSource()==badd)
	        {
	        h=Double.parseDouble(t.getText());
	        choice="add";

	       t.setText(""); 
	        }
	        if(e.getSource()==bmin)
	        {
	        	  choice="sub";
	  	        h=Double.parseDouble(t.getText());
	 	       t.setText(""); 

	        }
	        if(e.getSource()==bmul)
	        {
	        	  choice="mul";
	  	        h=Double.parseDouble(t.getText());
	 	       t.setText(""); 

	       }
	        if(e.getSource()==bdiv)
	        {
	        	  choice="div";
	  	        h=Double.parseDouble(t.getText());
	 	       t.setText(""); 

	        }
	        if(e.getSource()==bsin)
	        {
	          choice="sin";
	  	       t.setText(" ");

	        }
	        if(e.getSource()==bcos)
	        {
	        	choice="cos";
	  	       t.setText(" ");

	        }
	        if(e.getSource()==btan)
	        {
	        	 choice="tan";
	  	       t.setText(" ");

	        }
	        if(e.getSource()==bcot)
	        {
	  	       choice="cot";
	  	       t.setText(" ");

	        }
	        if(e.getSource()==bcosec)
	        {
	  	       choice="cosec";
	  	       t.setText(" ");

	        }
	        if(e.getSource()==bsec)
	        {
	  	       choice="sec";
	  	       t.setText(" ");

	        }
	        if(e.getSource()==bsq)
	        {
	  	       choice="sq";
	  	       t.setText(" ");

	        }
	        if(e.getSource()==blog)
	        {
	  	       choice="log";
	  	       t.setText(" ");

	        }





	        if(e.getSource()==bequal)
	        {
	        	  
		        l=Double.parseDouble(t.getText());

	        
	        switch(choice)
	        {
	        case "add":
	        	result=h+l;
	        	break;
	        case "sub":
	        	result=h-l;
	        	break;
	        	case "mul":
		        	result=h*l;
		        	break;
	        	case "div":
		        	result=h/l;
		        	break;
	        	case "sin":
	        		result= Math.sin(l);
	        		break;
	        	case "sec":
	        		result=1/ Math.cos(l);
	        		break;
	        	case "cos":
	        		result=Math.cos(l);
	        		break;
	        	case "tan":
	        		result=Math.tan(l);
	        		break;
	        	case "cot":
	        		result=1/ Math.tan(l);
	        		break;
	        	case "cosec":
	        		result=1/ Math.sin(l);
	        		break;
	        	case "sq":
	        		result=Math.pow(l,2);
	        		break;
	        	case "log":
	        		result=Math.log10(l);
	        		break;



	        }
	        t.setText(""+result);
	}
	       	        if(e.getSource()==bc)
	        {
	        	t.setText( ""+0);
	        }
	        if(e.getSource()==bexit)
	        {
	       // t.setText(" ");
	        this.dispose();
	        }
	        
}
	   public static void main(String[] args) {
		   Calc c=new Calc();
		   
		 }

}
	        
	        
