import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.border.Border;


public class color extends JFrame implements ActionListener
{
	JButton jb=new JButton("pick background color");
	JFrame jf=new JFrame("color chooser dialogbox");	
	Container con;
		public color()
		{
		con=getContentPane();
	   con.add(jb,BorderLayout.CENTER);
		jb.addActionListener(this);
		}

		@Override
		public void actionPerformed(ActionEvent e) 
		{
			// TODO Auto-generated method stub
			if(e.getSource()==jb)
			{
			Color c=jb.getBackground();
			Color background=JColorChooser.showDialog(null, "sample color", c);
			if(c!=null)
				{
				jb.setBackground(background);
				}
			}
		}
		
			public static void main(String args[])
			{
				color c=new color();
				
				c.setSize(500, 500);
				c.setVisible(true);
				
			}
}
		
	
	



	

