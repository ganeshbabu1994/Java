import java.awt.*;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

//import javax.swing.JApplet;
import javax.swing.*;
//import javax.swing.*;


public class Event4 extends JFrame implements ItemListener
{
JCheckBox c;
JCheckBox c1;
JCheckBox c2;
JLabel j;
JLabel k;
JLabel l;

public e4()
{
	setLayout(new FlowLayout());
	setSize(100,200);
	c=new JCheckBox("java");
	c1=new JCheckBox("c");
	c2=new JCheckBox("visualbasic");
	j=new JLabel(" ");
	k=new JLabel(" ");
	l=new JLabel(" ");
add(j);
add(k);
add(l);
	add(c);
	add(c1);
	add(c2);
	c.addItemListener(this);
	c1.addItemListener(this);
	c2.addItemListener(this);

}
public void itemStateChanged(ItemEvent e) {  
	if(e.getSource()==c)
	{
    j.setText("java: "  + (e.getStateChange()==1?"true":"false"));
	}
	if(e.getSource()==c1)
	{
    k.setText("c: " + (e.getStateChange()==1?"true":"false"));
	}
	if(e.getSource()==c2)
	{

    l.setText("visualbasic: "  + (e.getStateChange()==1?"true":"false"));
	}

 }           
public static void main(String[] args) {
e4 obj=new e4();
obj.setVisible(true);
	}

}
