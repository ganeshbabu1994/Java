import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import org.jdatepicker.impl.DateComponentFormatter;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

public class databasereg extends JFrame implements ActionListener
{

	JFrame f=new JFrame();

	JLabel j1,j2,j3,j4,j5,j6,j7,j8,j9,j10,j11,j12;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11;
	  JButton btn1, btn2;
	  JRadioButton r1=new JRadioButton("Male");
		JRadioButton r2=new JRadioButton("Female");
	  JPasswordField p1=new JPasswordField();
	  JPasswordField p2=new JPasswordField();
		UtilDateModel model = new UtilDateModel();
		Properties p = new Properties();
	
		JDatePanelImpl datePanel = new JDatePanelImpl(model,p);
		JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateComponentFormatter());
	
public Registration(){
		f.setVisible(true);
		f.setSize(300, 300);
		
		p.put("text.today", "Today");
		p.put("text.month", "Month");
		p.put("text.year", "Year");
		
		 
		

		j1=new JLabel("First name");
		j2=new JLabel("Last name");
		j3=new JLabel("DOB");
		
		j4=new JLabel("Gender");
		j5=new JLabel("Street");
		j6=new JLabel("City");
		j7=new JLabel("State");
		j8=new JLabel("Pincode");
		j9=new JLabel("mobile number");
		j10=new JLabel("EmailId");
		j11=new JLabel("password");
		j12=new JLabel("confirm password");
		
		 btn1 = new JButton("Submit");
	        btn2 = new JButton("Clear");
	 
		
		t1=new JTextField(20);
		t2=new JTextField(20);
		t3=new JTextField(20);
		t4=new JTextField(20);
		t5=new JTextField(20);
		t6=new JTextField(20);
		t7=new JTextField(20);
		t8=new JTextField(20);
		t9=new JTextField(20);
		t10=new JPasswordField(20);
		t11=new JPasswordField(20);

		ButtonGroup g =new ButtonGroup();
		f.setLayout(new GridLayout(14,2));
		g.add(r1);
		g.add(r2);
		f.getContentPane().add(r1);
		f.getContentPane().add(r2);
		f.add(j1);
		f.add(t1);
		f.add(j2);
		f.add(t2);
		f.add(j3);
		f.add(datePicker);
		f.add(j4);
		f.add(r1);
		f.add(new JLabel(" "));
		f.add(r2);

		f.add(j5);
		f.add(t4);
		f.add(j6);
		f.add(t5);
		f.add(j7);
		f.add(t6);
		f.add(j8);
		f.add(t7);
		f.add(j9);
		f.add(t8);
		f.add(j10);
		f.add(t9);
		f.add(j11);
		f.add(p1);
		f.add(j12);
		
		f.add(p2);
		  f.add(btn1);
	       f.add(btn2);
	       btn1.addActionListener(this);
	        btn2.addActionListener(this);
}


@Override
public void actionPerformed(ActionEvent e) {
if(e.getSource()==btn1)
{
	String tx1=t1.getText();
	String tx2=t2.getText();
	String tx3=t3.getText();
	String tx4=t4.getText();
	String tx5=t5.getText();
	String tx6=t6.getText();
	String tx7=t7.getText();
	String tx8=t8.getText();
	String tx9=t9.getText();

	char[] pwd = p1.getPassword();
	char[] pwd2 = p2.getPassword();
	String p1=new String(pwd);
	String p2=new String(pwd2);
	System.out.println(p1+"  "+p2);
	Date selectedDate =(Date) datePicker.getModel().getValue();
	  Calendar cal=Calendar.getInstance();

	  cal.setTime(selectedDate);
	    int syear =cal.get( Calendar.YEAR);
int  smonth=cal.get(Calendar.MONTH)+1;
int sday=cal.get(Calendar.DAY_OF_MONTH);


	Calendar now = Calendar.getInstance();
	int year = now.get(Calendar.YEAR);
	int month = now.get(Calendar.MONTH) + 1;
	int day=now.get(Calendar.DAY_OF_MONTH);
	int age=year-syear;

	if(smonth>month){
		age--;
	}
	else if(smonth==month){
		if(sday>day){
			age--;
		}
	}
		if(!((tx1.length()>=2 || tx1.length()<=20)  && tx1.matches("^[a-zA-Z][a-zA-Z][a-zA-Z0-9]*$"))){
			JOptionPane.showMessageDialog(null,"Min-2and max-20 characters. First 2-charccters should be alphabets");
		}
		else
		{
			System.out.println("1passed");
		}
		if(!((tx2.length()>=2 || tx2.length()<=20)))
				{
		JOptionPane.showMessageDialog(null, "Min-1 & Max-20 characters.");
				}
		else
		{
			System.out.println("2passed");
		}

	if(!(age>18))
	{
		JOptionPane.showMessageDialog(null, "Above 18 years");
	}
	else
	{
		System.out.println(" age passed");
	}

	if(!(r1.isSelected()==false)&&(r2.isSelected()==false))
	{		JOptionPane.showMessageDialog(null, "Can�t be empty");

	}
	else
	{
		System.out.println(" radio passed");
	}

	if(!(tx4.equals(""))||(tx5.equals(""))||(tx6.equals("")))
	{
				JOptionPane.showMessageDialog(null, "Can�t be empty");


}
	else
	{
		System.out.println(" all text passed");
	}

	if(!(tx7.matches("^[a-zA-Z]$"))&&(tx7.length()==6))
	{
		JOptionPane.showMessageDialog(null, "Must be 6-charcters. Alpha numeric.");

	}
	else
	{
		System.out.println(" pin passed");
	}

	if(!(tx8.matches("^[0-9]$"))&&(tx8.length()==10))
	{
		JOptionPane.showMessageDialog(null, "Must be 10-digits only");

	}
	else
	{
		System.out.println(" ph no passed");
	}

	if(!(tx9.matches("^[A-Za-z0-9_.%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,6}$"))){
		   JOptionPane.showMessageDialog(null,"enter a valid email address");	
	   }
	else
	{
		System.out.println(" email passed");
	}

	if(!(p1.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#`.``_``-`$%^&+=])[?=\\S+$]{6,12}$") && p1.equals(p2)))
	{
		   JOptionPane.showMessageDialog(null,"not valid password");	

	}
	else
	{
		System.out.println(" pass passed");
	}

}
if(e.getSource()==btn2){
	t1.setText("");
	t2.setText("");
	t4.setText("");
	t5.setText("");
	t6.setText("");
	t7.setText("");
	t8.setText("");
	t9.setText("");
	p1.setText("");
	t2.setText("");
	p2.setText("");
	r1.setSelected(false);
	r2.setSelected(false);
	
}

}


public static void main(String args[])
{
	databasereg r=new databasereg();
	r.setVisible(true);
}
}