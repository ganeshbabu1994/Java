import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.event.*;

public class e1 extends JFrame implements ActionListener{
	JButton b1;
	JButton b2;
	JLabel l2;
	JLabel l;

	public Event1()
	{
		setLayout(new FlowLayout());
	    setSize(200, 200);
		b1=new JButton("OK");
		add(b1);
		 b2=new JButton("EXIT");
		add(b2);
		 l2=new JLabel("Swing");
		 l=new JLabel(" ");
		add(l);

		add(l2);
		//JLabel l=new JLabel("OK button is pressed");
b1.addActionListener(this);
b2.addActionListener(this);
	}

	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==b1)
		{
			l.setText("ok button is pressed");
		}
		if(e.getSource()==b2)
		{
			this.dispose();
		}
	}

	public static void main(String[] args) {
		e1 obj=new e1();
		obj.setVisible(true);
		

	}

}
