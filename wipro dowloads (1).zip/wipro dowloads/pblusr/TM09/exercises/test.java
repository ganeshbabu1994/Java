package jdbc;

import java.sql.*;

public class test 
{
	public static void main(String args[]) throws SQLException
	{
	try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","tiger");
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(("select id,last_name from emp"));
		
while(rs.next())
{
	int a=rs.getInt(1);
	String s=rs.getString(2);
	System.out.println(a+" 	"+s);
}
		
		rs.close();
		
		}
	catch(Exception e)
			{
		System.out.println(e);
			}

	}
}