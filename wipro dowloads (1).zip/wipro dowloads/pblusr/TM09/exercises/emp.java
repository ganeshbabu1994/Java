package jdbc;

import java.sql.*;

public class emp
{
	public static void main(String args[]) throws SQLException
	{
	try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(("select last_name,job_id, hire_date,sal from employees"));
		
while(rs.next())
{
	
	String s=rs.getString(1);
	String s1=rs.getString(2);
	Date s2=rs.getDate(3);
	int a=rs.getInt(4);
	System.out.println(s+" 	"+s1+" 	"+s2+" 	"+a);
}
		
		rs.close();
		
		}
	catch(Exception e)
			{
		System.out.println(e);
			}

	}
}