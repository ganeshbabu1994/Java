package jdbc;

import java.sql.*;

public class commission
{
	public static void main(String args[]) throws SQLException
	{
	try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery("create table emptest (emp_id number(10), emp_name varchar2(15),birthdate varchar2(10),salary number(15))");
		st.executeUpdate("insert into emptest values(1001,'Ashish','20/12/1991',10000)");
	
		st.executeUpdate("insert into emptest values(1002,'Poornima', '01/03/1992', 12000)");

		}
	catch(Exception e)
			{
		System.out.println(e);
			}
	

	}
}
