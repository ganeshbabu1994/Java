package jdbc;

import java.sql.*;

public class type1 
{
	public static void main(String args[]) throws SQLException
	{
	try
		{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","tiger");
		System.out.println("connection done");
		
		}
	catch(Exception e)
			{
		System.out.println(e);
			}

	}
}