
package jdbc;

import java.sql.*;

public class metadataTest
{
	public static void main(String args[]) throws SQLException
	{
	try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","tiger");
		Statement st=conn.createStatement();
		DatabaseMetaData dmd=conn.getMetaData();
		ResultSet rs=st.executeQuery("select * from emp");
		String s1=dmd.getDriverName();
		String s2=dmd.getURL();
		System.out.println(s1+"	"+s2);
	
/*while(rs.next())
{
	int a=rs.getInt(1);
	String s1=rs.getString(2);
	String s2=rs.getString(3);
	int b=rs.getInt(4);
	Date c=rs.getDate(5);
	int s3=rs.getInt(6);
	int s4=rs.getInt(7);
	System.out.println(a+" 	"+s1+" 	"+s2+" 	"+b+" 	"+c+" 	"+s3+"	"+s4);
}*/
		
		rs.close();
		
		}
	catch(Exception e)
			{
		System.out.println(e);
			}

	}
}