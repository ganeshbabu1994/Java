import java.applet.Applet;
import java.awt.Graphics;


public class Applet1 extends Applet {
	public void init() {
		System.out.println("Init method invoked");
	}
	
	public void start() {
		System.out.println("start method invoked");
	}
	
	public void stop() {
		System.out.println("stop method invoked");
	}
	
	public void destroy() {
		System.out.println("Destroy method invoked");
	}		
}
