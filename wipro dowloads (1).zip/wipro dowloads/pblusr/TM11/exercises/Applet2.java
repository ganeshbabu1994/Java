import java.applet.*;
import java.awt.*;

/*
<applet code=Applet2 width=200 height=200>
<param name="str1" value="parameter 1 applet">
</applet>
*/


public class Applet2 extends Applet {
	String s1;
	public void init() {
		s1=getParameter("str1");
		
	}
	
	public void paint(Graphics g) {
		g.drawString(s1, 50, 50);
		
	}
}
