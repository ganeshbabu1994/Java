package applet;

import java.awt.*;
import java.applet.*;
import java.applet.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.*;

/*<applet code="clock.java" width="200" height="200">
</applet> */
public class time extends Applet implements Runnable{
   Thread t,t1;
   String bsbg=" ";
	int count=0;

   public void start(){
      t = new Thread(this);
      t.start();
   
   }
   public void run(){
      try{
		 
      while(true){
    	 
   	   Calendar cal = new GregorianCalendar();
      
    	  int sec = cal.get(Calendar.SECOND);
    	 
    	Random rand = new Random();
          if(sec%5==0 || sec==0){
        	  String [] name = {"tit for tat", "all is well", "truth alone triumps", "work hard to succeed"};
    	  bsbg = name[rand.nextInt(name.length)];
    	  count++;
          }      
          repaint();
          
           t.sleep(1000);    
            }}
         catch(InterruptedException e){}
      }
   
   public void paint(Graphics g){
	   SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss aa");
		   Date today = new Date();
      String curr=df.format(today);
      g.drawString(curr,150,10);
      
          g.setColor(Color.blue);
    	   g.drawString(bsbg, 100, 90);
    	  showStatus("proverb  :"+count);
	 }
}