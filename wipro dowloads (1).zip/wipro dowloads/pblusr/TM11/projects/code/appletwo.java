import java.applet.*;
import java.awt.*;

public class appletwo extends Applet {
	
	public void paint(Graphics g) {
		g.setColor(Color.red); 
		g.drawOval(10, 10, 40, 100);
		g.setColor(Color.red); 
		g.drawOval(100, 30, 40, 100);
		g.setColor(Color.red);   
		g.fillOval(100, 30, 40, 100);
	}
}
