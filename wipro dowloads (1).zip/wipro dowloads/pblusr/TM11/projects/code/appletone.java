import java.applet.*;
import java.awt.*;

public class appletone extends Applet {
	
	public void paint(Graphics g) {
		g.setColor(Color.pink); 
		g.drawArc(10, 10, 50, 150, 20, 50);
		g.setColor(Color.red);   
		g.fillArc(100, 10, 70, 100, 0, 90);
	}
}
