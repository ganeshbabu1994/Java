import java.applet.*;
import java.awt.*;

/*
<applet code=Applet2 width=200 height=200>
<param name="str1" value="parameter 1 applet">
<param name="str2" value="parameter 2 applet">
<param name="str3" value="parameter 3 applet">
<param name="str4" value="parameter 4 applet">
<param name="str5" value="parameter 5 applet">

</applet>
*/


public class Applet2 extends Applet {
	String s1,s2,s3,s4,s5;
	public void init() {
		s1=getParameter("str1");
		s2=getParameter("str2");
		s3=getParameter("str3");
		s4=getParameter("str4");
		s5=getParameter("str5");
	}
	
	public void paint(Graphics g) {
		g.drawString(s1, 50, 50);
		g.drawString(s2, 50, 60);
		g.drawString(s3, 50, 70);
		g.drawString(s4, 50, 80);
		g.drawString(s5, 50, 90);
	}
}
