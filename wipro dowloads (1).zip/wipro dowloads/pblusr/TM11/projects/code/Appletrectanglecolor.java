import java.applet.*;
import java.awt.*;

/*
<applet code=Appletrectanglecolor width=200 height=200>
</applet>
*/


public class Appletrectanglecolor extends Applet {
	
	public void paint(Graphics g) {
		g.drawRect(10, 10, 50, 100);
		g.setColor(Color.red);   
		g.fillRect(10, 10, 50, 100);
		g.drawRect(100, 100, 50, 50);
		g.setColor(Color.red);   
		g.fillRect(100, 100, 50, 50);
	}
}
