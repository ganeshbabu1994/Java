import java.applet.*;
import java.awt.*;
import java.io.IOException;

import javax.imageio.ImageIO;

public class image extends Applet {
	Image img;
	public void init() {
		try {
			img = ImageIO.read(getClass().getResourceAsStream("Lighthouse.jpg"));
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void paint(Graphics g) {
		g.drawImage(img, 10, 10, this);
	}
	
}
