import java.applet.*;
import java.awt.*;

/*
<applet code=Appletrectangle width=200 height=200>
</applet>
*/


public class Appletrectangle extends Applet {
	
	public void paint(Graphics g) {
		g.drawRect(10, 10, 50, 100);
		g.drawRect(100, 100, 50, 50);
	}
}
