
public class employee 
{
double annsal;
int year;
String insnum;
employee()
{
super();
}
public void setAnnsal(double annsal)
{
this.annsal=annsal;
}
public void setYear(int year)
{
this.year=year;
}
public void setInsnum(String insnum)
{
this.insnum=insnum;
}
public double getAnnsal()
{
return this.annsal;
}
public int getYear()
{
return this.year;
}
public String getInsnum()
{
return this.insnum;
}
public String toString()
{
return(this.annsal+"  "+this.year+"  "+this.insnum);
}
}
