class testemployee 
{
public static void main(String args[])
{
employee te=new employee(20.5, "2000" ,"12l214");
System.out.println(te);
}
}


