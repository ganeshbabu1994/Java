class Box
{
double width;
double height;
double depth;
void setWidth(double x)
{
width=x;
}
void setHeight(double y)
{
height=y;
}
void setDepth(double z)
{
depth=z;
}
public double vol()
{
double volume;
volume=width*height*depth;
return volume;
}
public static void main(String args[])
{
Box b=new Box();
b.setWidth(5);
b.setHeight(4);
b.setDepth(3);
System.out.println(b.vol());
}
}

