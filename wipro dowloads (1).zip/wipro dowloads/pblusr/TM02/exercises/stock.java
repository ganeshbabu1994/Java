class stock
{
String sname;
String ssymbol;
double preprice;
double currprice;
stock(String a,String b,double c,double d)
{
this.sname=a;
this.ssymbol=b;
this.preprice=c;
this.currprice=d;
}
public double getChangePercentage()
{
double val;
val=(((preprice-currprice)/(preprice))*100);
System.out.println("Stock name"+"	"+"ssymbol"+"	"+"preprice"+"	"+"currprice"+"      " +"change in percentage"+"		");
System.out.print(this.sname+"		"+this.ssymbol+"	"+this.preprice+"		"+this.currprice);
return(val);
}
public static void main(String args[])
{
stock s=new stock("product","$$",50,40);
System.out.print("		"+s.getChangePercentage()+"%");
}
}