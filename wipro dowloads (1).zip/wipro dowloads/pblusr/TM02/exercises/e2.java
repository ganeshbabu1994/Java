import java.util.*;
 class e2
{
e2()
{
System.out.println("constructor");
}
public static void m1(int x)
{
int i;
i=x;
System.out.println(i);
}
public static void main(String args[])
{
e2 e=new e2();
e.m1(5);
}
}
