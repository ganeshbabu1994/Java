class testemployee extends employee
{
public static void main(String args[])
{
employee te=new employee();
person p1=new person("ganesh");
te.setAnnsal(2000.5);
te.setYear(2000);
te.setInsnum("12L214");
System.out.println(te);
System.out.println(p1);
}
}


