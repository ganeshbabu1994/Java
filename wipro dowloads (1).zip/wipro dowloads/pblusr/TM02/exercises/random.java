import java.util.*;
import java.lang.*;
class randomhelper
{
static int m,n;
static int randint(int x,int y)
{
m=x;
n=y;
static int n=max-min;
int m=(int)(n*Math.random());
return m;
}
class rand
public static void main(String[] args)
{
random r=new random();
r.randint(1,10);
System.out.println();
}
}
}
