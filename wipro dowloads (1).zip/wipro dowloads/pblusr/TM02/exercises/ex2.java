class stock
{
String sname;
String ssymbol;
double preprice;
double currprice;
stock()
{
this("product","$$",50,100);
}
public double getChangePercentage()
{
double val;
val=(preprice-currprice)/(preprice*100);
return val;
}
public static void main(String args[])
{
stock s=new stock();
System.out.println(val);
}
}