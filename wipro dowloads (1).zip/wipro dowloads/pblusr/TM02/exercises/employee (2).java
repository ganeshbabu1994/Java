
public class employee extends person
{
double annsal;
String year;
String insnum;
employee(double annsal,String year,String insnum)
{
super("ganesh");
this.annsal=annsal;
this.year=year;
this.insnum=insnum;
}
public String toString()
{
return(super.name+"  "+this.annsal+"  "+this.year+"  "+this.insnum);
}
}
