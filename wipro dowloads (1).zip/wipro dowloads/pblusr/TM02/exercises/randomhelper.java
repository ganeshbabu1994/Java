import java.util.*;
import java.lang.*;
class randomhelper
{
static int max,min;
static int f;
static int randint(int x,int y)
{
min=x;
max=y;
f=(((max+1)-min)+min);
int j=(int)(f*1*Math.random());
return j;
}
}
class random
{
public static void main(String args[])
{

System.out.println(randomhelper.randint(1,10));
}
}

