import java.util.*;
import java.io.*;
class parrent
{
int a=10;
}
class child extends parrent
{
int a=5;
void display()
{
System.out.println(super.a);
}
public static void main(String args[])
{
child c1=new child();
c1.display();
}
}
