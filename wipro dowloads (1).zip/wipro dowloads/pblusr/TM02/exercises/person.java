

public class person
{
public String name ;
person(String name)
{
this.name=name;
}
}