  class e1
{
e1() {
        
System.out.println("Within constructor");
        
  
}
static
 {
       
 System.out.println("Within 1st static block");
        
   
 }
 static void m1()
 {
       
 System.out.println("Within static m1 method");
        
  
  }

public static void main(String args[])
{
e1 e=new e1();
e1.m1();
 }
static
 {
        
System.out.println("Within 2nd static block");
        
}


}
