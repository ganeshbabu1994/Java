import java.util.*;
class parrentchild
{
int a;
Scanner in=new Scanner(System.in)
a=in.nextInt();
}
class child extends parrent
{
public static void main(String args[])
{
int a;
System.out.println(a);
}
}