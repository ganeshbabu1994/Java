
class Video 
{

	private String title;
	private Boolean flag = false;
	private double averageRating;
	private int sum = 0;
	private int count = 0;
	
         void setTitle(String title1) 
        {
		title = title1;
	}
	 String getTitle() 
        {
		return title;
	}
	 void addRating(int rate) 
        {
		sum = rate + sum;
		count = count + 1;
		averageRating = sum / count;
	}
	 double getRating() 
        {
		return averageRating;
	}
	 void beingCheckedOut() 
        {
		flag = true;
	}
	 void beingReturned() 
        {
		flag = false;
	}
	 Boolean checkedOut() 
        {
		return flag;
	}
}
class VideoStore 
{
	Video[] cd = new Video[10];
	int vCount;
	public void addVideo(String title) 
        {
		if (vCount > 10) 
                {
			System.out.println("videos are full");
		} 
                else 
                {
			cd[vCount] = new Video();
			cd[vCount].setTitle(title);
			vCount++;
                   
		}
	}

	void checkOut(String v1) 
        {
          for (int i = 0;i<vCount;i++) 
             {
	       if (v1.equals(cd[i].getTitle()))
                 {

		cd[i].beingCheckedOut();
                  break;
                 }
	     }
       }

	void returnVideo(String v2) 
        {
           for (int i = 0;i<vCount;i++) 
             {
	       if (v2.equals(cd[i].getTitle()))
               { 
		cd[i].beingReturned();
                   break;
               }
	     }
       }

	 void receiveRating(String v3, int rating) 
         {
             for (int i = 0;i<vCount;i++) 
             {
	       if (v3.equals(cd[i].getTitle()))
	        {
  	          cd[i].addRating(rating);
                  break;
                }
           
	     }
         }

	 double ratingForVideo(int v4) 
            {
		return cd[v4].getRating();
	    }

	 void listInventory()
           {
		for (int i = 0; i < vCount; i++) 
                {		
			if (cd[i].checkedOut()) 
                        {
				continue;
			}
                       else 
                        {
		        System.out.println(i + ": " + cd[i].getTitle());
			System.out.println("\tRating:" + ratingForVideo(i));
			}
		}
	}
}

class VideoStoreLauncher 
   {
	public static void main(String[] args) 
        {
		Video vid1 = new Video();
		VideoStore vs = new VideoStore();
		
		vs.addVideo("The Matrix");
		vs.addVideo("The Godfather");
		vs.addVideo("Star Wars Episode");
		vs.receiveRating("The Matrix", 5);
		vs.receiveRating("Star Wars Episode", 4);
		vs.receiveRating("The Godfather", 4);
		vs.receiveRating("The Matrix", 3);
		vs.receiveRating("Star Wars Episode", 5);
		vs.receiveRating("Star Wars Episode", 4);
		vs.receiveRating("The Godfather", 4);
		vs.receiveRating("The Godfather", 3);
		vs.checkOut("The Matrix");
		vs.checkOut("City of Angels");
                vs.returnVideo("The Matrix");
                vs.returnVideo("City of Angels"); 
                vs.checkOut("The Godfather");
		System.out.println("Average Rating for video #0: "
				+ vs.ratingForVideo(0));
		vs.listInventory();
                
        }
}

	
 

