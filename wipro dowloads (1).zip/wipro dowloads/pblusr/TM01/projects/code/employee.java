class employee
{
public static void main(String args[])
{
String[] des={"e","c","k","r","m"};
String[] empno={"1001","1002","1003","1004","1005","1006","1007"};
 String[] empname={"anish","sushma","rahul","chahat","ranjan","suman","tanmay"};
 String[] joindate={"01/04/2009","23/08/2012","12/11/2008","29/01/2013","16/07/2005","1/1/2000","12/06/2006"};
String[] Dept={"R&D","PM","ACCT","FRONT DESK","ENGG","MANUFACTURING","PM"};
int[] basic={20000,30000,10000,12000,50000,23000,29000};
int[] hra={8000,12000,8000,6000,20000,9000,12000};
int[] it={3000,9000,1000,2000,20000,4400,10000};
int f='\0';
int len=empno.length;
int salary;
for(int i=0;i<len;i++)
{
if(args[0].equals(empno[i]))
{
 f=i;
}}
System.out.println("EmpId"+"	"+"EName"+"	       "+"Department"+"	 "+"Designation"+"	  "+"Salary");
System.out.print(empno[f]+"	"+empname[f]+"	"+"	"+Dept[f]+"	");
String s1=des[f];
switch(s1)
{
case "e":	
	int da1=20000;
	salary=(basic[f]+hra[f]+da1)-(it[f]);       
        System.out.print("engineer"+"	"+salary);
	break;
case "c":	
	int da2=32000;
	salary=(basic[f]+hra[f]+da2)-(it[f]);       
        System.out.print("consultant"+"	"+salary);
	break;

case "k":	
	int da3=12000;
	salary=(basic[f]+hra[f]+da3)-(it[f]);       
        System.out.print("clerk"+"	"+salary);
	break;
case "r":	
	int da4=15000;
	salary=(basic[f]+hra[f]+da4)-(it[f]);       
        System.out.print("receptionist"+"	"+salary);
	break;
case "m":	
	int da5=40000;
	salary=(basic[f]+hra[f]+da5)-(it[f]);       
        System.out.print("manager"+"	"+salary);
	break;

       }
}
}

