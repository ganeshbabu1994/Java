import java.util.*;
class bubbles
{
public static void main(String args[])
{
int b[]=new int[args.length];
int i,j;
int temp;
int len=b.length;
System.out.println("Before sorting");
for(i=0;i<b.length;i++)
{
 b[i]=Integer.parseInt(args[i]);
System.out.println(b[i]);
}
for(i=0;i<len;i++)
{
for(j=0;j<len-i-1;j++)
{
if(b[j]>b[j+1])
{
temp=b[j];
b[j]=b[j+1];
b[j+1]=temp;
}
}
}
System.out.println("After sorting");
for(i=0;i<len;i++)
{
System.out.println(b[i]);
}
}
}
