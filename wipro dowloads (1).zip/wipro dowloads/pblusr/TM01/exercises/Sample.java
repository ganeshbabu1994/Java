import java.io.*;

class Sample
{
    public static void main(String args[])
    {
	String s=args[0];
	int len =s.length;
	System.out.println(len);
    }
}