class reverse
{
public static void main(String args[])
{
int len=args.length;
int m[]=new int[len];
int k='\0';
int temp=0;
if(len==4)
{
for(int i=0;i<len;i++)
{
 m[i]=Integer.parseInt(args[i]);
}
 int[][] a=new int[2][2];
for(int i=0;i<2;i++)
{
for(int j=0;j<2;j++)
{
a[i][j]=m[k];
k++;
}
}
System.out.println("given array are");
for(int i=0;i<2;i++)
{
for(int j=0;j<2;j++)
{
System.out.print(a[i][j]);
}
System.out.println();
}
System.out.println("reverse array are");
for(int i=1;i>=0;i--)
{
for(int j=1;j>=0;j--)
{

System.out.print(a[i][j]);
}
System.out.println();
}
}
else
{
System.out.println("please enter four integer");
}
}
}
