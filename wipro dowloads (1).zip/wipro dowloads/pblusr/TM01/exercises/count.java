import java.util.*;
class count
{
public static void main(String args[])
{
int[] a=new int[4];
int max=a[0];
int count=1;
Scanner in=new Scanner(System.in);
System.out.println("enter the values");
for(int i=0;i<a.length;i++)
{
a[i]=in.nextInt();
}
System.out.println("max value is");
for(int i=0;i<a.length;i++)
{
if(a[i]>max)
{
max=a[i];
if(max==a[i])
{
count++;
}
else{
continue;
}
}
 }

System.out.println(max+" 	"+count);
}
}