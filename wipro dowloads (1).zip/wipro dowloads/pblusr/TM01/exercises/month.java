class month
{
public static void main(String args[])
{
int len=args.length;
if(len!=0)
{
int a=Integer.parseInt(args[0]);
String m;
switch (a)
{
case 1:  m="january";
            	 break;
case 2:  m="feburary";
            	 break;
case 3:  m="march";
            	 break;
case 4:  m="april";
            	 break;
case 5:  m="may";
            	 break;
case 6:  m="june";
            	 break;
case 7:  m="july";
            	 break;
case 8:  m="august";
            	 break;
case 9:  m="september";
            	 break;
case 10:  m="october";
            	 break;
case 11:  m="november";
            	 break;
case 12:  m="december";
            	 break;
default: m="not a valid month";
	break;
}
System.out.println(m);
}
else
System.out.println("please enter the valid month");
}
}


 