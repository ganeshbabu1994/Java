import java.util.*;
class twod
{
public static void main(String args[])
{ 
int len=args.length;
int m[]=new int[len];
int k='\0';
int temp=0;
for(int i=0;i<len;i++)
{
 m[i]=Integer.parseInt(args[i]);
}
 int[][] a=new int[len/3][len/3];
for(int i=0;i<len/3;i++)
{
for(int j=0;j<len/3;j++)
{
a[i][j]=m[k];
k++;
}
}
for(int i=0;i<len/3;i++)
{
for(int j=0;j<len/3;j++)
{
System.out.print(a[i][j]);
}
System.out.println();
}
int max=a[0][0];
for(int i=0;i<len/3;i++)
{
for(int j=0;j<len/3;j++)
{
if(a[i][j]>max)
{
max=a[i][j];
}}
}
System.out.print("max value in array"+" "+max);
}
}

