class factorial
{
public static void main(String args[])
{
int a=Integer.parseInt(args[0]);
int sum=1;
for(int i=1;i<=a;i++)
{
sum=sum*i;
}
System.out.println(sum);
}
}
