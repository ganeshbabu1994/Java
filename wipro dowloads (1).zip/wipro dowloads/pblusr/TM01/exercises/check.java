import java.util.*;
class check
{
public static void main(String args[])
{
int a=Integer.parseInt(args[0]);
int flag=0;
if(a==0|| a==1)
{
System.out.println("neither composite nor prime");
}
else{
for(int j=2;j<a;j++)
{
if(a%j==0)
{
System.out.println("not a prime number");
flag=1;
break;
}
}
if(flag==0)
{
System.out.println("prime number");
}
}
}
}
