import java.util.*;
class integer
{
public static void main(String args[])
{
int[] a=new int[25];
int max=a[0];
Scanner in=new Scanner(System.in);
System.out.println("enter the values");
for(int i=0;i<a.length;i++)
{
a[i]=in.nextInt();
}
System.out.println("max value is");
for(int i=0;i<a.length;i++)
{
if(a[i]>max)
{
max=a[i];
}
}
System.out.println(max);
 }
}
