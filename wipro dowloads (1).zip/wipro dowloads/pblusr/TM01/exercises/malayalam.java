class malayalam
{
	public static void main(String args[])
	{
		String a="malayalam";
		String b="\0";
		int count=0;
		for(int i=0;i<a.length();i++)
		{
			for(int j=0;j<b.length();j++)
			{
			
				if(a.charAt(i)==b.charAt(j))
				
					count=1;
					
				
			
				
					
			}
					         if(count==0)
					   b+=a.charAt(i);
				
			count=0;

		}
		System.out.println(b);
	}
}

