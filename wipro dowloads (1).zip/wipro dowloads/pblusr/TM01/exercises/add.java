import java.util.*;
class add
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int a[]=new int[10];
int sum=0;
System.out.println("enter the values");
for(int i=0;i<10;i++)
{
a[i]=in.nextInt();
sum=sum+a[i];
}
System.out.println(sum);
}
}
