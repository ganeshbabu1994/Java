package exception;

import java.util.*;
import java.io.*;
abstract class Account 
{
	double interestrate;
	double amount;
	int noofdays;
	public double interest;

	public abstract double calculateinterest(double amount);
}



class FDaccount extends Account
{
	double interestrate;
	double amount;
	int noofdays;
	int ageofaccountholder;
	boolean flag=false;
	int x,y;
	FDaccount(double amount,int noofdays,int ageofaccountholder,int x,int y)
	{
		
		this.amount=amount;
		this.noofdays=noofdays;
		this.ageofaccountholder=ageofaccountholder;
		this.x=x;
		this.y=y;
		if(this.ageofaccountholder>=60 && x>=7&&y<=14)
		{
		interestrate=5.00;
		flag=true;
		System.out.println((interestrate*this.noofdays*this.amount)/100);
		}
		else if(this.ageofaccountholder<60 && x<=y)
		{
		interestrate=4.50;
		flag=false;
		System.out.println((interestrate*this.noofdays*this.amount)/100);
		}
	
	}
	
	
	
	
		public double calculateinterest(double amount)
		{

		if(flag)
			if(amount>10000000)
			{
				interestrate=6.50;
			interest=(interestrate*this.noofdays*this.amount)/100;
			}
			return interest;
			
		}

}


	class SBaccount extends Account
	{
		double interestrate;
		double amount;
		boolean flag=false;
		private int noofdays;
		private int ageofaccountholder;
		int x,y;
		SBaccount(double amount,int noofdays,int ageofaccountholder,int x,int y)
		{
			
			this.amount=amount;
			this.noofdays=noofdays;
			this.ageofaccountholder=ageofaccountholder;	
			this.x=x;
			this.y=y;
		if(this.ageofaccountholder>=60 && x>=0 && y>=6)
		{
			flag=true;
			interestrate=8.0;
		}
		else
		{
			flag=false;
			interestrate=7.50;
		}
			
		}
		
		
		public double calculateinterest(double amount) {
		
			if(flag)
			{
			return (interestrate*this.noofdays*this.amount/100);
			}
			if(!flag)
			interest=(this.amount*this.noofdays*interestrate)/100;
			return interest;
		}
		
		public String toString()
		{
			return	"interest :" +interest;
		}

	}
	
		
	
	
	 class RDaccount extends Account
	{
		double interestrate;
		double amount;
		int noofmonths;
		double monthlyamount;
		int ageofaccountholder;
		boolean flag=false;
	RDaccount(double amount,int noofmonths,int ageofaccountholder)
	{
		
		this.amount=amount;
		this.noofmonths=noofmonths;
		this.ageofaccountholder=ageofaccountholder;
		if(this.ageofaccountholder>=60)
		{
		flag=true;
		   interestrate=6;
		}
	else
	{
		flag=false;
	    interestrate=4;
	
	}
}
		public double calculateinterest(double amount)
		{
			this.amount=amount;
				if(flag)
				{
					interest= (interestrate*this.noofmonths*this.amount/100);
				}
				else
				{
					interest=(interestrate*this.noofmonths*this.amount/100);
				
				}
				return interest;
		}
				
		public String toString()
		{
			return	"interest :" +interest;
		}

				
	}

	class cal
{
	public static void main(String args[])
	{

		Account A;
		 Scanner in = new Scanner(System.in);
		int choice;
		choice= in.nextInt();
		switch(choice)
		{
		case 1:
				
				FDaccount FD=new FDaccount(10000,91,65,7,14);
				A=FD;
				A.calculateinterest(10000);
				System.out.println(FD);
				break;
		case 2:
				
				SBaccount SB=new SBaccount(200,12,12,13,15);
				A=SB;
				A.calculateinterest(200);
				System.out.println(SB);
				break;
		case 3:	
				
				RDaccount RD=new RDaccount(300,12,12);
				A=RD;
				A.calculateinterest(300);
				System.out.println(RD);
				break;
		
		default:
			    System.out.println("Exit");
			    break;
			    
		
	     }
	}
}

