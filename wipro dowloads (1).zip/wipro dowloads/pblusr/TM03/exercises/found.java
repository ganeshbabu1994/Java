package test;
import testpackage.*;
public class found extends foundation
{
	public static void main(String args[])
	{
		foundation f=new foundation();

System.out.println(f.var3);
System.out.println(f.var4);
}
}
