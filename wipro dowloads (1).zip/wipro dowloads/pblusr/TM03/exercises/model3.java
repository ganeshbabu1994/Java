
import java.lang.*;
import java.util.*;
import java.io.*;
public class model3
{
	public static void main(String args[])
	{
	int size=Integer.parseInt(args[0]);
	int a[]=new int[size];
	try{
		for(int i=0;i<args.length;i++)
	{
			a[i]=Integer.parseInt(args[i+1]);
		}
	for(int i=0;i<size;i++)
	{
			System.out.println(a[i]);
	}
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}

	private static int nextInt() {
		// TODO Auto-generated method stub
		return 0;
	}
}