package e1;
import java.lang.*;
import java.math.*;
abstract class Compartment {

	public abstract void notice();

}
class Firstclass extends Compartment
{
	public void  notice()
	{
		System.out.println("Firstclass compartment");	
	}
}
class Ladies extends Compartment
{
	public void  notice()
	{
		System.out.println("ladies compartment");	
	}
}
class General extends Compartment
{
	public void notice()
	{
		System.out.println("general compartment");
	}
}
class Luggage extends Compartment
{
	public void  notice()
	{
		System.out.println("Luggage");	
	}
}
class TestCompartment
{
	public static void main(String args[])
	{
		Compartment c[]=new Compartment[3];
		int r=(int)(4*Math.random()+1);
	switch(r)
	{
	case 1:
		c[1]=new Firstclass();
		c[1].notice();
		break;
	case 2:
		c[2]=new Firstclass();
		c[2].notice();
		break;
	case 3:
		c[3]=new Firstclass();
		c[3].notice();
		break;
	case 4:
		c[4]=new Firstclass();
		c[4].notice();
		break;
	}

}
}
