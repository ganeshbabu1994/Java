package nine;
import java.util.*;
public class nine {
	
	public static void main(String args[]) {
		
		System.out.println("Enter the 2 numbers: ");
		int a = Integer.parseInt(args[0]);
		int b = 0;
		
	
		try {
			int q = a/b ;
			if(q != 0) {
				
				System.out.println("The quotient of " +a+ "/" +b+ " = " +q);
			}
			
		}
		catch (Exception e) {
			System.out.println("DivideByZeroException caught");
		}
	
		finally {
			System.out.println("Inside finally block");
		}
	}
}