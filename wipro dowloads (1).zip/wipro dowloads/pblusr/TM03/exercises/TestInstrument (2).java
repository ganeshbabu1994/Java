
abstract class Instrument {

	public abstract void functionplay();
}
class Piano extends Instrument
{
public void functionplay()
	{
		System.out.println("Piano is playing  tan tan tan tan ");
	}
}
class Flute extends Instrument
{
	public void functionplay()
	{
		System.out.println("Flute is playing  toot toot toot toot");
	}
}
 class Guitar extends Instrument
{
	 public void functionplay()
	{
		System.out.println("Flute is playing  toot toot toot toot");
	}
}

public class TestInstrument
{
	public static void main(String args[])
	{
		Instrument[] i=new Instrument[4];
		Piano p=new Piano();
		Flute f=new Flute();
		Guitar g=new Guitar();
		i[0]=p;
		i[1]=f;
		i[2]=g;
		i[3]=p;
		if(i[0] instanceof Instrument)
		{
			i[0].functionplay();
		}
		if(i[1] instanceof Instrument)
		{
			i[1].functionplay();
		}
		if(i[2] instanceof Instrument)
		{
			i[2].functionplay();
		}
		if(i[3] instanceof Instrument)
		{
			i[3].functionplay();
		}
	}
}
