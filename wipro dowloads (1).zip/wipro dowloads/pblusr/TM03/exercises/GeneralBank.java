package bank;
import java.lang.*;
abstract class GeneralBank {
	int f1;
	int f2;
	GeneralBank(int x,int y)
	{
	f1=x;
	f2=y;
		}
	abstract double getSavingInterestRate();
	abstract double getFixedInterestRate();
}	
 class ICICIBank extends GeneralBank
 {
	 ICICIBank(int x,int y)
	 {
		super(x,y); 
	 }
	 double getSavingInterestRate()
	{
		System.out.println("saving account");
		return f1;
	}
	 double getFixedInterestRate()
	{
		System.out.println("fixed account");
		return f2;
	}
}
 class KotMBank extends GeneralBank
 {
	 KotMBank(int x,int y)
	 {
		 super(x,y); 
	 }
	 double getSavingInterestRate()
	{
		System.out.println("saving account");
		return f1;
	}
	 double getFixedInterestRate()
	{
		System.out.println("fixed account");
		return f2;
	}	 
 }
 class bank
 {
	 public static void main(String args[])
	 {
		 GeneralBank G;
		 ICICIBank b1=new ICICIBank(4,8);
		 KotMBank b2=new KotMBank(6,9);
		 G=b1;
		 System.out.println("ICICI BANK"+G.getSavingInterestRate()+"%");
		 System.out.println("KOTAK BANK"+G.getFixedInterestRate()+"%");
		 G=b2;
		 System.out.println("ICICI BANK"+G.getSavingInterestRate()+"%");
		 System.out.println("KOTAK BANK"+G.getFixedInterestRate()+"%");
	 }
 }