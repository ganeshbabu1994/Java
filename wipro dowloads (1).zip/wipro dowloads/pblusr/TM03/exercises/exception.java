package exception;

public class exception 

{
	public static void main(String args[])
	{
		char a='h';
		try
		{
			int b=9/0;
			if(a==5)
			{
			try
				{
				System.out.println(a/0);
				}
			catch(ArithmeticException e)
		{
			System.out.println(e);
		}
			

			}
		}
		catch(Exception e)
		{
			System.out.println("hai");
		}
	finally
	{
		System.out.println("today coding the end");
	}
}
}
