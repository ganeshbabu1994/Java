package com.wipro.automobile.ship;

public class Compartment {
	
double height;
double width;
double breadth;
	Compartment(double x,double y,double z)
	{
		height=x;
		width=y;
		breadth=z;
	}
	double area()
	{
		double area=this.height*this.width*this.breadth;
		return area;
	}
	public static void main(String args[])
	{
	Compartment c=new Compartment(12,10,10);
	System.out.println(c.area());
	
	}
}