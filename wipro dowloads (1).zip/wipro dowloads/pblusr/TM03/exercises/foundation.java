package testpackage;

public class foundation {
	private static int var1=1;
	protected static int var3=3;
	int var2=2;
	public int var4=4;
}




