import java.util.*;


public class hashmap {
	public static void main(String args[])
	{
		TreeMap tm=new TreeMap();
		String[] s1 = null;
		int count=1;
		int len = 0;
		int m=0;
		String s2[] = null;
		int m1=0;
		
		tm.put("Manoj works at Wipro"," ");
		tm.put("Katari works at Wipro"," ");
		tm.put("Sureka works at Wipro"," ");
		tm.put("Harish works at Wipro"," ");
		tm.put("Anitha works at Wipro"," ");
		Set val=tm.entrySet();
Iterator it=val.iterator();
		while(it.hasNext())
		{
			Map.Entry e=(Map.Entry)it.next();
			//System.out.println(e.getKey()+"		"+e.getValue());
			String s=(String)e.getKey();
			s1=s.split(" ");
		
			 len=s1.length;
			 for(int i=0;i<len;i++)
				{
					
						String st=s1[i];
						 m1=s1.length;
					System.out.println(st);

					
				}
			 System.out.println(m1);	
		}
		
	
	}

}


