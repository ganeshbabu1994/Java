package T4m;
import java.util.*; 
public class ArrayListTest
{
	public static void main(String[] args)
	{
		List<String> test = new ArrayList<String>();
		String s = "hi";
		test.add("string");
		test.add(s);
		test.add(s+s);
		System.out.print(test.size());
		System.out.print(test.contains(42));
		System.out.print(test.contains("hihi"));
		test.remove("hi");System.out.print(test.size());
	}
}
