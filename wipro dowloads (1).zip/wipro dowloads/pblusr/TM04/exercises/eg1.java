package exception;
import java.lang.*;
import java.io.*;
public class eg1 extends Exception
{
	String name;
	int age;
	eg1(String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	public String toString()
	{
		return (this.name+"	"+this.age+"\n"+"not eligible to work");
	}
}
class e1
{
public static void main(String args[])
{
	String s1=args[0];
	int i=Integer.parseInt(args[1]);
	if(18<i	&&	i<60)
	{
		System.out.println(s1+" working ");
		}
	
	else{
		try{
		
throw new eg1(s1,i);
	}
	
	catch(eg1 e)
	{
		System.out.println(e);
	}
}
	
}
}
