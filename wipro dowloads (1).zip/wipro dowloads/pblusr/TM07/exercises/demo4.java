package Threaddemo;

public class demo4 extends Thread
{
	int count=0;
public void run()
{
	count++;
System.out.println("count:"+count);

}
public static void main(String args[]) throws InterruptedException
{
	demo4 D=new demo4();
	Thread t1=new Thread(D);
	t1.start();
	t1.sleep(100);
	Thread t2=new Thread(D);
	t2.start();
}
	
}
