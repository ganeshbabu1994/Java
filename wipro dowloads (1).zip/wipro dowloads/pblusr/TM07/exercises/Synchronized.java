
public class Synchronized implements Runnable {
	int count=0;
	public synchronized void increment()
	{
		count++;
		System.out.println(count);
	}
	public void run()
	{
		increment();
		/*try {
			wait();

			notify();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}*/
	}
public static void main(String args[])
{
	Synchronized S=new Synchronized();
	try
	{
	Thread t1=new Thread(S);
	Thread t2=new Thread(S);
	t1.start();
	t2.start();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}
}
