package Threaddemo;
import java.lang.*;
public class demo3 implements Runnable{
	int count=0;
	public void run()
	{
		count++;
		System.out.println("count:"+count);
	}
		
	public static void main(String args[]) throws InterruptedException
	{
		
		demo1 D=new demo1();
		Thread t1=Thread.currentThread();
		try{
		Thread.sleep(100);
		t1.setName("Ganesh");
		System.out.println("Name:"+t1);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	
	}

}
