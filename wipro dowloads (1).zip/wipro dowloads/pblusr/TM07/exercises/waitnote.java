package waitnotify;

public class waitnote implements Runnable
{
	public static int sum=0;
	public static void main(String args[]) throws InterruptedException
	{
		waitnote w=new waitnote();
		Thread t1=new Thread(w);
		
		try
		{
			t1.start();
		synchronized (w)
		{
			System.out.println("Waiting State");
			w.wait();
		}
		System.out.println("executed after notify: SUM is:"+sum);
		}
		catch(Exception e)
		{

			System.out.println(e);
		}
	}
	public void run()
	{
		try
		{
		synchronized (this)
		{
			for(int i=0;i<=5;i++)
			{
				sum=sum+i;
			}
			notify();
		}
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		}
	

}
