package atm;

class ABC  {
	int amnt;
	ABC()
	{
		amnt=1000;	
	}
	public synchronized void withdraw(int x)
	{
	try
		{
		Thread.sleep(100);
		}
	catch(Exception e)
		{
		System.out.println(e);
		}
	amnt=amnt-x;
	System.out.println(amnt);
	}
}
	class B implements Runnable
		{
		
		ABC a;
	public B(ABC b)
		{
			a=b;
		}
	public void run()
	{
		a.withdraw(100);
	}

		}

public class atm
{
	public static void main(String args[])
	{
		ABC a1=new ABC();
		B a2=new B(a1);
		
		Thread t1=new Thread(a2);
		Thread t2=new Thread(a2);
		Thread t3=new Thread(a2);
		t1.start();
		t2.start();
		t3.start();
	}
}
