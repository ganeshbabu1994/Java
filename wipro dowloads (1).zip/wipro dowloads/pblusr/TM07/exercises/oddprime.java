package synchronisationlast;

class syn implements Runnable
{
	public void odd()
	{
		for(int i=1;i<=10;i++)
		{

			int m=i%2;
			if(!(m==0))
			{
				System.out.println(i);
				
			}
		}
	}
	
	public void eve()
	{
		for(int i=1;i<=10;i++)
		{
			int m=i%2;
			if(m==0)
			{
				System.out.println(i);
			}
			
		}
	}
	
	public void run()
	{
		eve();
		odd();
	}	
}



public class oddprime {
	
	public static void main(String args[])
	{
		syn S=new syn();
		Thread t1=new Thread(S);
		Thread t2=new Thread(S);
		t1.start();
		t2.start();
		
	}

}
