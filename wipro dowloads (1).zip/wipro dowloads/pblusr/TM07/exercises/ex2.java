package Threaddemo;

public class ex2 extends Thread{
	
	
	public static void main(String args[])
	{
		
		{
		ex2 d=new ex2();

	 Thread t1=new Thread(d);
	 t1.setName("Scobby");
		System.out.println(t1.getName());

		 Thread t2=new Thread(d);
		 t2.setName("Shaggy");
		 System.out.println(t2.getName());
	}

}
}

