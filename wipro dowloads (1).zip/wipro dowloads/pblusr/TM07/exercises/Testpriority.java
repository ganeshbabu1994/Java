
public class Testpriority implements Runnable {
	public void run()
	{
		System.out.println(Thread.currentThread().getName());
		System.out.println(Thread.currentThread().getPriority());
	}
	public static void main(String args[])
	{
		Testpriority T=new Testpriority();
		Thread t1=new Thread(T);
		t1.setName("hai");
		Thread t2=new Thread(T);
		t2.setName("hello");
		Thread t3=new Thread(T);
		t3.setName("you");
		t1.setPriority(Thread.NORM_PRIORITY);
		t2.setPriority(Thread.MAX_PRIORITY);
		t3.setPriority(Thread.MIN_PRIORITY);
		t1.start();
		t2.start();
		t3.start();
		
	}

}
