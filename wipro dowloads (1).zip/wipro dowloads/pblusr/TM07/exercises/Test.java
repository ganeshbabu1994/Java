package Test;
import Threaddemo.*;
public class Test {
public static void main(String args[]) throws InterruptedException
{
	example e1=new example("1");
	example e2=new example("2");
	example e3=new example("3");
	System.out.println("1 is alive or not"+e1.t1.isAlive());
	System.out.println("2 is alive or not"+e2.t1.isAlive());
	System.out.println("3 is alive or not"+e1.t1.isAlive());
	
	/*e1.t1.join();
	e2.t1.join();
	e3.t1.join();*/
	
}
}
