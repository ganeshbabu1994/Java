


public class checkpriority 	extends Thread {
	


	public void run()
	{
		double d= 22/7;
		for(int i=0;i<10;i++)
		{
			System.out.println(d);

System.out.println(Thread.currentThread().getPriority());
		}
	}

	public static void main(String args[])
	{

		checkpriority p=new checkpriority();
	Thread t1=new Thread(p);
	t1.setName("A");
	Thread t2=new Thread(p);
	t2.setName("B");
	Thread t3=new Thread(p);
	t3.setName("C");
	
	t1.setPriority(3);
	t2.setPriority(2);
	t3.setPriority(1);
	
	t1.start();
	t2.start();
	t3.start();

	
}
}
