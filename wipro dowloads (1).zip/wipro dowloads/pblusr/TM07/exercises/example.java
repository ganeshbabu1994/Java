package Threaddemo;

public class example implements Runnable
{
	
	public String name;
	public Thread t1;
	public example(String x)
		{
		name=x;
	Thread t1=new Thread(name);
	System.out.println("thread name"+t1);
	t1.start();
		}
	public void run()
	{
		try
		{
			for(int i=0;i<10;i++)
			{
				System.out.println(i);
				t1.sleep(1000);
			}
		}
		
		catch(Exception e)
		{
		System.out.println(e);
	}
		System.out.println(name+"Exiting");
	
}
	}


