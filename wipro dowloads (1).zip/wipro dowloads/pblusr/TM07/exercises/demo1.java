package Threaddemo;
import java.lang.*;
public class demo1 implements Runnable{
	int count=0;
	public void run()
	{
		count++;
		System.out.println("count:"+count);
	}
		
	public static void main(String args[]) throws InterruptedException
	{
		
		demo1 D=new demo1();
		Thread t1=new Thread(D);
		t1.start();
		t1.sleep(100);
		Thread t2=new Thread(D);
			t2.start();
			t2.sleep(100);
	
		
		//D.start();
		//D.currentThread( );
	}

}
