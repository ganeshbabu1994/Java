package Synk;

class EX 
{
	public void msg(String name)
	{
		System.out.print("["+name);
	try
	{
		Thread.sleep(1000);
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	System.out.println("]");

}
}
class ex1 implements Runnable
{
	String name;
	EX a;
	Thread t;
	public ex1(EX m,String n)
	{
		a=m;
		name=n;
		t=new Thread(this);
		t.start();
		
	}
	public void run()
	{
		synchronized(a)
		{
			a.msg(name);
		}
	}
	
}

class main
{
	public static void main(String args[])
	{
		EX c=new EX();
		ex1 b1=new ex1(c,"hai");
		ex1 b2=new ex1(c,"hello");
		ex1 b3=new ex1(c,"you");
		
		
	}
}
