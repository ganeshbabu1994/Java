package Threaddemo;

public class demo2 extends Thread
{
	int count=0;
public void run()
{
	count++;
System.out.println("count:"+count);

}
public static void main(String args[]) throws InterruptedException
{
	demo2 D=new demo2();
	D.start();
	D.sleep(100);
	demo2 D1=new demo2();
	D1.start();
	D1.sleep(100);
	demo2 D2=new demo2();
	D2.start();
	D2.sleep(100);
}
	
}
