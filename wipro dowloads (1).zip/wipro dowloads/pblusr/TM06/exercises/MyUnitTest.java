package Package1;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyUnitTest {
	
	MyUnit mu = null;
	@Test
	public void testStringConcat() {
		mu = new MyUnit();
		assertEquals("Result","RameshSwayampakula", mu.stringConcat("Ramesh", "Swayampakula"));
	}

}
