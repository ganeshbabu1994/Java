package junit.test;

import static org.junit.Assert.*;
import junit.first.Calculator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CalculatorTest {
	Calculator c = null;
	@Before
	public void before() {
		System.out.println("Before test");
	}
	
	@After
	public void after() {
		System.out.println("After Test");
	}
	
	@Test
	public void testAdd() {
		c = new Calculator();
		assertEquals("Result",5,c.add(2,3));
	}

	@Test
	public void testSub() {
		c = new Calculator();
		assertEquals("Result",2,c.sub(5,3));
	}

}
