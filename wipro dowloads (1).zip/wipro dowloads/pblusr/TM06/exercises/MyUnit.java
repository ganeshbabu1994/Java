package Package1;

public class MyUnit {
	

	public String stringConcat(String x, String y) {
		//String a = stringConcat(x,y);
		return 	x+y;
	}
}