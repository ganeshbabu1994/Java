package Junittesting;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertArrayEquals;

import java.util.Stack;

import org.junit.BeforeClass;
import org.junit.Test;

public class MyUnitStackTest {

  static Stack stack;
 static Integer[] array;
 static Integer[] copyArray;
 
 @BeforeClass
 public static void oneTimeSetUp() {
  //Initialization code goes here
  System.out.println
            ("Inside the @BeforeClass function");
  stack = new Stack();
  array=new Integer[]{1,0,1};
  copyArray=new Integer[3];
}
 @Test
 public void testStackAddItems() {
  System.out.println
            ("Inside testStackAddItems() ");
  for(Integer temp:array){
   stack.push(temp);
  }
  assertEquals(3, stack.size());
 }
 @Test
 public void testStackRemoveAllItems() {
  System.out.println
            ("Inside testStackRemoveAllItems() ");
  int k = stack.size();
 // stack=new Stack();
  for(int i=0;i < k; i++){
   copyArray[i]=(Integer) stack.pop();
   System.out.println (" popped element = "+copyArray[i]);
  }
  
  assertTrue(stack.isEmpty());
  assertArrayEquals(array, copyArray);
 }
 
}