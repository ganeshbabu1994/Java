package JunitAnnotationsTest;

import java.util.ArrayList;








import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertArrayEquals;
public class JunitAnnotationsTest
{
    private ArrayList<String> testList=new ArrayList<String>();
  @BeforeClass
    public static void onceExecutedBeforeAll() { 
     System.out.println("@BeforeClass: onceExecutedBeforeAll");
    }
  @Before
    public void executedBeforeEach() {
        System.out.println("@Before: executedBeforeEach");
    }
  @AfterClass
    public static void onceExecutedAfterAll() {
     System.out.println("@AfterClass: onceExecutedAfterAll");
    }
  @After
    public void executedAfterEach() {
        testList.clear();
        System.out.println("@After:executedAfterEach");
    }
  @Test
    public void EmptyCollection() {
    //Insert code to test whether list is empty 
	  testList.isEmpty();
        System.out.println("@Test: EmptyArrayList");

    }
  @Test
    public void OneItemCollection() {
        testList.add("oneItem");
    //Insert code to test whether list size is 1
       System.out.println("@Test: OneItemArrayList");
    }
  @Ignore
   public void executionIgnored() {
      System.out.println("@Ignore: This execution is ignored");
   }

}