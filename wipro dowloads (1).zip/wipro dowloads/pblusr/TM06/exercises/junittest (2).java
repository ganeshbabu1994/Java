package package3;

import static org.junit.Assert.*;

import org.junit.Test;

public class junittest {
	MyUnit m = null;
	@Test
	public void test() {
		MyUnit m = new MyUnit();
		assertEquals("Result",true, m.palindromeCheck("malayalam"));
	}

}
