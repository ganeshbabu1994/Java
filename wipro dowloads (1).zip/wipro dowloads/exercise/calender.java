package applet;

import java.applet.Applet;
import java.awt.Graphics;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class calender extends Applet implements Runnable {


	Thread t1,t2;
	public void start()
	{
		t1=new Thread(this);
		t1.start();	
	}
	
	public void run()
	{
		t2=Thread.currentThread();
		while(t1==t2)
		{
			repaint();
			try {
				t1.sleep(100);
			} 
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	
	}
	public void paint(Graphics g)
	{
		GregorianCalendar c=new GregorianCalendar();
		String hour=String.valueOf(c.get(Calendar.HOUR));
		String min=String.valueOf(c.get(Calendar.MINUTE));
		String sec=String.valueOf(c.get(Calendar.SECOND));
		g.drawString(hour+":"+min+":"+sec,50, 50);
		
		
	}


	
	
}
