package com.wipro.ata.listener;


import java.sql.*;

import com.wipro.ata.bean.CredentialsBean;
import com.wipro.ata.bean.ProfileBean;
import com.wipro.ata.util.DBUtil;
import com.wipro.ata.util.User;


public class RegisterListener implements User {

Connection conn;
PreparedStatement ps;
Statement st;
ResultSet rs;
String userid;String sts,pss;
Date d=new Date(45); 
CredentialsBean c=new CredentialsBean();

@Override
public String register(ProfileBean profileBean) {
	conn=new DBUtil().getDBConnection("oracle.jdbc.driver.OracleDriver");
	pss="insert into ATA_TBL_USER_PROFILE values(?,?,?,?,?,?,?,?,?,?,?,?)";
	sts="select ATA_SEQ_USERID.nextval from dual";
	try {
	st=conn.createStatement();
	ps=conn.prepareStatement(pss);
	rs=st.executeQuery(sts);
	while(rs.next()) 
		{
		  userid = rs.getInt(1)+profileBean.getFirstName().substring(0,2);
		  System.out.println("*"+userid);
		  sts="insert into ATA_TBL_USER_CREDENTIALS values('"+userid +"','"+profileBean.getPassword()+"','A',1)";
		  st.executeQuery(sts);
		}
	
		ps=conn.prepareStatement(pss);
		ps.setString(1,userid);
		ps.setString(2,profileBean.getFirstName());
		ps.setString(3, profileBean.getLastName());
		ps.setDate(4, d/*(Date) profileBean.getDateOfBirth()*/);
		ps.setString(5,profileBean.getGender());
		ps.setString(6, profileBean.getStreet());
		ps.setString(7,profileBean.getLocation());
		ps.setString(8, profileBean.getCity());
		ps.setString(9,profileBean.getState());
		ps.setString(10, profileBean.getPincode());
		ps.setString(11,profileBean.getMobileNo());
		ps.setString(12, profileBean.getEmailID());
		int j=ps.executeUpdate();
		
		if(j==1)
		{
		
		return userid; 
		}
		else{
			return "FAIL";
			}
		
	} catch (SQLException e) {
		
		e.printStackTrace();return "FAIL";
	}
	
	
}

@Override
public boolean logout(String userId) {
	conn=new DBUtil().getDBConnection("oracle.jdbc.driver.OracleDriver");
	return false;
}

@Override
public String login(CredentialsBean credentialsBean) {
	conn=new DBUtil().getDBConnection("oracle.jdbc.driver.OracleDriver");
	String str="INVALID";
	pss="select * from ATA_TBL_USER_CREDENTIALS where userid='"+credentialsBean.getUserID()+"' and password='"+credentialsBean.getPassword()+"'";
	try {
		ps=conn.prepareStatement(pss);
		rs=ps.executeQuery();
		
		while(rs.next())
		{
			//System.out.println(rs.getString(1)+"  "+rs.getString(2));
		str=rs.getString(3);

		sts="update ATA_TBL_USER_CREDENTIALS set LOGINSTATUS=1where userid='"+credentialsBean.getUserID()+"'";
		int j=st.executeUpdate(sts);
		}
		} catch (SQLException e) {
		
		e.printStackTrace();return "FAIL";
	}
	return str;
	
}

@Override
public String changePassword(CredentialsBean credentialsBean, String s) {
	conn=new DBUtil().getDBConnection("oracle.jdbc.driver.OracleDriver");
	c=credentialsBean;
	String str=credentialsBean.getUserID();
	sts="select * from ATA_TBL_USER_CREDENTIALS where USERID='"+str+"'";
	String s1="",s2="",s3="";
	try {
		st=conn.createStatement();
		rs=st.executeQuery(sts);
		while(rs.next()){s1=rs.getString(1);
		s2=rs.getString(2);
		s3=rs.getString(3);}
		System.out.println(s1+" "+s2+" "+s3+" "+credentialsBean.getUserID()+" "+credentialsBean.getUserType());
		if(credentialsBean.getUserID().equalsIgnoreCase(s1)&&credentialsBean.getUserType().equalsIgnoreCase(s3))
		{
			sts="update ATA_TBL_USER_CREDENTIALS set password='"+s+"' where USERID='"+str+"'";
			int j=st.executeUpdate(sts);
			if(j==1){return "SUCCESS";}
		}else
		{
			return "INVALID";
		}
		
		
		
		
		
		
	} catch (SQLException e) {
		
		e.printStackTrace();return "FAIL";
	}
	
	return null;
}





}
