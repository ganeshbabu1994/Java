package com.automobile.TwoWheeler;
import com.automobile.*;
 
class Honda extends Vehicle {


int speed;
	Honda(String mname,String regno,String oname,int speed)
	{
		
		super(mname,regno,oname);
		this.speed=speed;
	}
public String getModelName(){
	return super.modelName;
}
public String getRegistrationNumber()
{
	return super.regno;
}
public String getOwnerName()
{
	return super.ownername;
}
public int getSpeed()
{
	return this.speed;
}
public void cdplayer()
{
	System.out.println("this model provides a facility to control the cd player device");
}
}


