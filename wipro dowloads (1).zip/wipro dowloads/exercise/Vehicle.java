package com.automobile;

abstract public class Vehicle {
	public String modelName;
	public String regno;
	public String ownername;
	
	public Vehicle(String mname,String regno,String oname)
	{
		this.modelName=mname;
		this.regno=regno;
		this.ownername=oname;
		
	}
	
	
public abstract String getModelName();
public abstract String getRegistrationNumber();
public abstract String getOwnerName();



}
