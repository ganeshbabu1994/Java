package swing;

import java.math.BigInteger;
import java.util.Scanner;

public class TestClass {
	 static Scanner in=new Scanner(System.in);

	 public static void main(String args[] ) throws Exception {
	      
	       long a = in.nextInt();
	       long ten=10;
	       BigInteger rem; 
	        int count=0;
	       BigInteger fact=new BigInteger("1");
	     
	       for(long i=2;i<=a;i++){
	 	       fact=fact.multiply(BigInteger.valueOf(i));
}
	  BigInteger no=fact;
	  
	       
	       System.out.println(fact);
	       while(fact.compareTo(BigInteger.ZERO) > 0){
	    	  rem=no.mod(new BigInteger("10"));
	    	  if(rem.compareTo(BigInteger.ZERO)== 0){
	    		 count++; 
	    		 
	    	  }
	    	  else{
	    		  break;
	    	  }
	    	  no=no.divide(new BigInteger("10"));
	       }
	       System.out.println(count);

}}