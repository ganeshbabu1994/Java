
	import java.io.*;
import java.util.*;
public class Readfile {

	public static void main (String args[ ]) throws IOException {
		Scanner in=new Scanner(System.in);
		
	//File input=new File("1.txt");
	File output=new File("1.txt");
//	FileReader inreader=new FileReader(input);
	FileWriter outreader=new FileWriter(output);
	BufferedReader bread=new BufferedReader(new InputStreamReader(System.in));
	BufferedWriter bwrite=new BufferedWriter(outreader);
	int c;
	
	/*do {
	/*c =  inreader.read( );
	outreader.write(c);
	}while (c!=-1);*/
	String str = " ";
do{
	
		outreader.write(str);
	//bwrite.newLine();
	}while(!(bread.equals("eof")));
	
	outreader.close();
	//bread.close();
	bwrite.close();
	}
	}



