import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;


public class Event3 extends JFrame {
	JLabel l;
	public Event3()
	{		
		addMouseListener(new Mouse (this));

		l=new JLabel(" ");
		add(l);
	
	}
	class Mouse extends MouseAdapter
	{
		Event3 e;
		public Mouse(Event3 e)
		{
			this.e=e;
		
		}
	

	
	

	
public void mouseClicked(MouseEvent me){
	l.setText("mouse clicked at:" +me.getClickCount());
	
}
	}
	public static void main(String[] args) {
Event3 obj=new Event3();
obj.setVisible(true);
	}
}	