import java.io.*;
import java.util.Map;
//import java.io.FileWriter;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.TreeMap;


public class File3 {

	public static void main(String[] args) throws IOException {
		TreeMap<String,Integer> tr=new TreeMap<String,Integer>();
		Scanner in=new Scanner(System.in);
		System.out.println("enter the file name");
		String str1=in.next();
		//File f=new File(str1);
		System.out.println("enter the file name");
		String str2=in.next();
		//File f1=new File(str2);
		FileReader inn=new FileReader(str1);
		FileWriter out=new FileWriter(str2);
		BufferedReader br=new BufferedReader(inn);
		BufferedWriter bf=new BufferedWriter(out);
String str,words=null;
//int i=0;
while((str=br.readLine())!=null)
{
	StringTokenizer s=new StringTokenizer(str," ");
	while(s.hasMoreTokens())
	{
		 words=s.nextToken();
		Integer count=tr.get(words);
		if(count==null)
		{
	
			count = 0;
		}
		
			tr.put(words, count+1);
		
		
				
	}
}
	for(Map.Entry m:tr.entrySet())
	{
		bf.write(m.getValue()+ " "+m.getKey());
		
	}
	

	

inn.close();
out.close();
		}

}
