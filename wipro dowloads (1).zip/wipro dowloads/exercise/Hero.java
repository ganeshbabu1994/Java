package com.automobile.TwoWheeler;
import com.automobile.*;
 class Hero extends Vehicle{
   int speed;
	Hero(String mname,String regno,String oname,int speed)
	{
		
		super(mname,regno,oname);
		this.speed=speed;
	}
public String getModelName()
{
	return super.modelName;
}
public String getRegistrationNumber()
{
	return super.regno;
}
public String getOwnerName()
{
	return super.ownername;
}
public int getSpeed()
{
	return this.speed;
}
public void radio()
{
	System.out.println("this model provides a facility to control a device");
}
}
