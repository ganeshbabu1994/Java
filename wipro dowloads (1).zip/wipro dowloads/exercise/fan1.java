import java.util.*;
import java.io.*;
import java.lang.*;

class Fan{
public static final int SLOW=1;
public static final int MEDIUM=2;
public static final int FAST=3;
private int speed=1;
private boolean fanstate=false;
private double radius=5;
private String colour="red";
Fan(){

}
public void setSpeed(int speed)
{
this.speed=speed;
}
public void setRadius(double radius)
{
this.radius=radius;
}
public void setColour(String colour)
{
this.colour=colour;
}
public void setFanstate(boolean state)
{
this.fanstate=state;
}
public int getSpeed()
{
return this.speed;
}
public double getRadius()
{
return this.radius;
}
public String getColour()
{
return this.colour;
}
public boolean isFanstate()
{
return fanstate;
}
public String toString()
{
if(fanstate)
{


switch(this.getSpeed()){

case 1:System.out.println("speed : slow");break;
case 2:System.out.println("speed : medium");break;
case 3:System.out.println("speed : fast");break;
default: System.out.println("enter speed between 1 to 3"); break;
}
return ("\nRadius:"+this.radius+"\nColor:"+this.colour);
}
else
{
return ("fan is in off state"+"\nRadius:"+this.radius+"\nColor:"+this.colour);
}}
}
class fan1
{
public static void main(String a[])
{
Fan f=new Fan();
f.setFanstate(true);
f.setSpeed(10);
f.setColour("Red");
f.setRadius(5);
System.out.println(f);
}
}