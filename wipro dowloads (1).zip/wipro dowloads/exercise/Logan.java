package com.automobile.FourWheeler;
import com.automobile.*;
public class Logan extends Vehicle {
	int speed;
public	Logan(String mname,String regno,String oname,int speed)
	{
		
		super(mname,regno,oname);
		this.speed=speed;
	}
public String getModelName(){
	return super.modelName;
}
public String getRegistrationNumber()
{
	return super.regno;
}
public String getOwnerName()
{
	return super.ownername;
}
public int getSpeed()
{
	return this.speed;
}
public void gps()
{
	System.out.println("this model provides a gps control to the device");
}
}
