package com.wipro;

public class Cube {
	
	public boolean isCube(int N)
	{
		boolean status=false;
	   int j,k,c1=0;j=N/2;   
	   int c=0;
	   if(N==1)   
	   {
		   status=true;
		   return status;
	    }
	   for(k=2;k<=j;k++)    
	   {
		   if(N%k==0)  
		   {
			   if((k*k*k)==N)
			   {
				   c1=1;         
			}}}
	   if(c1==1)    
	   {
		   status=true;
	    }else{
	    	status=false;
	    	}
	   return status;
	   }

}
