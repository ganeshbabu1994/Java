package com.wipro.ata.ui;




import java.awt.Container;

import javax.swing.*;

import com.wipro.ata.bean.CredentialsBean;
import com.wipro.ata.listener.RegisterListener;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ForgetPassword extends JFrame implements ActionListener{

	JLabel l1,l2,l3;
	JTextField t1,t2;
	JPasswordField p1;
	JFrame f; 
	JPanel pp;
	Container con;
	JButton b;
	Connection cont;
	PreparedStatement ps;
	ResultSet rs;
	CredentialsBean credentialsBean=new CredentialsBean();
	ForgetPassword()
	{
		f=new JFrame("Forgot Password");
		f.setSize(500,500);
		f.setLocation(200,80);
		f.setVisible(true);
		f.setLayout(null);
	
		pp=new JPanel();
		
		l1=new JLabel("USERID");
		l1.setBounds(70,30,80,20);
		t1=new JTextField(10);
		t1.setBounds(200,30,150,20);
		l2=new JLabel("USER TYPE");
		l2.setBounds(70,65,150,20);
		t2=new JTextField(10);
		t2.setBounds(200,65,150,20);
		l3=new JLabel("NEW PASSWORD");
		l3.setBounds(70,100,150,20);
		p1=new JPasswordField(10);
		p1.setBounds(200,100,150,20);
		b=new JButton("CHANGE");
		b.setBounds(200,180,120,20);
		b.addActionListener(this);
		f.add(l1);
		f.add(t1);
		f.add(l2);
		f.add(t2);
		f.add(l3);
		f.add(p1);
		f.add(b);
		
		
		
		
	}
	public static void main(String[] args) {
		ForgetPassword fp=new ForgetPassword();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b)
		{
			credentialsBean.setUserID(t1.getText());
			credentialsBean.setUserType(t2.getText());
			String s=p1.getText();
			System.out.println(new RegisterListener().changePassword(credentialsBean,s));
		}
	}

}

