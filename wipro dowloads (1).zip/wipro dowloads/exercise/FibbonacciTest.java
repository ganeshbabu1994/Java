package com.wipro;

import static org.junit.Assert.*;

import org.junit.Test;

public class FibbonacciTest {

	@Test
	public void test() {
		Fibbonacci f=new Fibbonacci();
		assertEquals(13,f.nthFibonacci(8));
		
	}

}
