import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;


public class multi {

	public static void main(String[] args) {
		JFrame frame = new TestFrame("TestFrame");
		frame.setSize(400,400);
		frame.setLocation(100,100);
		
		frame.setVisible(true);
		JPanel mypanel= new JPanel();
		String[] str={"one","two","three","four","five","six"};
		JList obj=new JList(str);
		obj.setVisibleRowCount(3);

		JScrollPane obj1=new JScrollPane(obj);
		mypanel.add(obj1);
		frame.getContentPane().add(mypanel);



	}

}
