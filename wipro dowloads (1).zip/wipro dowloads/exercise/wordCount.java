import java.util.*;
import java.io.*; 
public class wordCount {
	public static void main (String args[ ]) throws IOException {
		File input=new File("1");
		File output=new File("2");
		FileReader inreader=new FileReader(input);
		FileWriter outreader=new FileWriter(output);
		BufferedReader bread=new BufferedReader(inreader);
		BufferedWriter bwrite=new BufferedWriter(outreader);
		TreeMap<String,Integer> tm=new TreeMap<String,Integer>();
String s=null,s1;
Integer count=0;

while((s=bread.readLine())!=null){
			StringTokenizer st=new StringTokenizer(s," ");
			while(st.hasMoreTokens()){
				s1=st.nextToken();
				count=tm.get(s1);
				if(count==null){
					count=0;
				}
			tm.put(s1, count+1);
			}
		}
		
		for(Map.Entry m:tm.entrySet()){
			bwrite.write(m.getKey()+" "+m.getValue());
			bwrite.newLine();
		}
bwrite.close();
bread.close();

}
}