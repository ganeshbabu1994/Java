package swing;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.*;

public class count {
	public static void main(String args[])
	{
	JFrame f=new Layout1("my_Layout");
	
	f.setSize(300,300);
	f.setVisible(true);

	JPanel jp=new JPanel();
	JComboBox com=new JComboBox();
	com.addItem("Apple");
	com.addItem("orange");
	com.addItem("mango");

	com.addItem("lemon");

	com.addItem("papaya");

	com.addItem("banana");

	
	int i=com.getItemCount();
	JLabel jl=new JLabel("there are "+i+" items in the combobox");
	jp.add(com);
	jp.add(jl);

	 f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
jp.setLayout(new BorderLayout());
	f.setVisible(true);
	f.getContentPane().add(jp);
	}

}
