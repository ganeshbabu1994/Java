package com.wipro.ata.ui;



import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Home extends JFrame implements ActionListener{
	JLabel user,pass,log;
	//JComboBox ch;
	JButton login,reg;
	JTextField usertxt,passtxt;
	JCheckBox rem;
	JPanel p=new JPanel();
	
	
	public Home(String str)
	{
		setTitle(str);
		p.setLayout(null);
		String string[]={"Administrator","customer"};
		//ch=new JComboBox(string);
		log =new JLabel("LoginType");
		user=new JLabel("Username");
		pass =new JLabel("Password");
		usertxt=new JTextField(20);
		passtxt=new JTextField(20);
		login=new JButton("Login");
		reg=new JButton("Register");
		rem=new JCheckBox("Remember me on this computer");
		JLabel l1=new JLabel("forgot your password?");
		p.add(l1);
		l1.setBounds(50,250,150,20);
		JLabel l2=new JLabel("");
		l2.setText("<HTML><FONT color=\"#000099\">click here to reset it</FONT></HTML>");
		p.add(l2);
		l2.setBounds(200,250,150,20);
	    log.setBounds(8, 30, 80,25);
		//ch.setBounds(100, 30, 150,25);
		user.setBounds(10,80,80,25);
		usertxt.setBounds(100,80,150,25);
		pass.setBounds(10,130,90,25);
		passtxt.setBounds(100,130,150,25);
		rem.setBounds(10, 180,300,25);
		login.setBounds(350,180, 100, 25);
		reg.setBounds(550, 180,100, 25);

		p.add(log);
		//p.add(ch);
		p.add(user);
		p.add(usertxt);
		p.add(pass);
		p.add(passtxt);
		p.add(rem);
		p.add(login);
		p.add(reg);
		login.addActionListener(this);
		reg.addActionListener(this);
		//reg.setVisible(false);
		//login.setVisible(false);
		//ch.addItemListener(this);
		
		
		getContentPane().add(p);
		}

	
	
	public static void main(String args[])
	{
		Home obj=new Home("LOGIN");
		obj.setSize(200,200);
		obj.setVisible(true);
		
	}
	@Override
	public void actionPerformed(ActionEvent e) 
	{
	
		if(e.getSource()==reg)
		{
			new Register();
		}
		
		
	}
	

}
