import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.CheckboxMenuItem;
import java.awt.GridLayout;
import java.awt.Label;
import java.util.Properties;

import javax.swing.*;


public class project3 extends JFrame 
{
	public static void main(String args[])
	{
		JFrame jf=new JFrame();
		JPanel jp=new JPanel();
		JButton jb=new JButton("Submit");
		jf.setSize(300,355);
		JLabel l1,l2,l3;	
		JTextField t1;
		l1=new JLabel("Name");
		t1=new JTextField(16);
		l2=new JLabel("Graduation");
		l3=new JLabel("Additional interest");

	
		jp.add(l1);
		jp.add(t1);
		jp.add(l2);
		//jp.setLayout(new ));
		//jp.add(l2,BorderLayout.LINE_START);
		CheckboxGroup g=new CheckboxGroup();
		jp.add(new Checkbox("Social service",g,true));
		jp.add(new Checkbox("Sports",true));
		jp.add(new Checkbox("Cultural",true));
		jp.add(l3);
		
		jp.add(new Checkbox("UG",true));
		jp.add(new Checkbox("PG",false));
		jp.add(new Checkbox("diplomo",false));
		jp.add(jb);
		jf.getContentPane().add(jp);
		jf.setVisible(true);
		
	}
}
	
	


