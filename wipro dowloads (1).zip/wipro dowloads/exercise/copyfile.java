
	import java.io.*;
public class copyfile {

	public static void main (String args[ ]) throws IOException {
	File input=new File("1.txt");
	File output=new File("a.txt");
	InputStream inreader=new FileInputStream(input);
	//FileReader inreader=new FileReader(input);

	//BufferedReader bread=new BufferedReader(new InputStreamReader(inreader));
OutputStream outwriter= new FileOutputStream(output);
		//BufferedWriter bwrite=new BufferedWriter(outwriter);
	int c;
byte b[]=new byte[1024];	
	/*	String str;
while((str=bread.readLine())!=null){
	
		bwrite.write(str);
		((BufferedWriter) bwrite).newLine();
	}*/
	while((c=inreader.read(b))>0){
		outwriter.write(b,0,c);
		
	}
	System.out.println("File Successfully copied!!!!");

	inreader.close();
	outwriter.close();
	
	//	bread.close();
//	bwrite.close();
	}
	}







