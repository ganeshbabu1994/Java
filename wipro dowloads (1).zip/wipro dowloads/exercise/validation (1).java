package swing;



import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.*;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.plaf.basic.BasicBorders.RadioButtonBorder;

import org.jdatepicker.impl.*;

import java.net.PasswordAuthentication;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.lang.*;

//import swing.DateLabelFormatter;

public class validation extends JFrame implements ActionListener
{
	
	JFrame f=new JFrame();
	ButtonGroup g =new ButtonGroup();
	JLabel j1,j2,j3,j4,j5,j6,j7,j8,j9,j10,j11,j12;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11;
	  JButton btn1, btn2;
	  JRadioButton r1=new JRadioButton("Male");
		JRadioButton r2=new JRadioButton("Female");
	  JPasswordField p1=new JPasswordField();
	  JPasswordField p2=new JPasswordField();
		UtilDateModel model = new UtilDateModel();
		Properties p = new Properties();
	
		JDatePanelImpl datePanel = new JDatePanelImpl(model,p);
		JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateComponentFormatter());
	
public validation(){
		f.setVisible(true);
		f.setSize(300, 300);
		
		p.put("text.today", "Today");
		p.put("text.month", "Month");
		p.put("text.year", "Year");
		
		 
		

		j1=new JLabel("First name");
		j2=new JLabel("Last name");
		j3=new JLabel("DOB");
		
		j4=new JLabel("Gender");
		j5=new JLabel("Street");
		j6=new JLabel("City");
		j7=new JLabel("State");
		j8=new JLabel("Pincode");
		j9=new JLabel("mobile number");
		j10=new JLabel("EmailId");
		j11=new JLabel("password");
		j12=new JLabel("confirm password");
		
		 btn1 = new JButton("Submit");
	        btn2 = new JButton("Clear");
	 
		
		t1=new JTextField(20);
		t2=new JTextField(20);
		t3=new JTextField(20);
		t4=new JTextField(20);
		t5=new JTextField(20);
		t6=new JTextField(20);
		t7=new JTextField(20);
		t8=new JTextField(20);
		t9=new JTextField(20);
		t10=new JPasswordField(20);
		t11=new JPasswordField(20);
		
		/*  btn1.setBounds(50, 350, 100, 30);
	        btn2.setBounds(170, 350, 100, 30);
		  j1.setBounds(80, 70, 200, 30);
		   j2.setBounds(80, 100, 200, 30);
		   j3.setBounds(80, 130, 200, 30);
		   j4.setBounds(80, 160, 200, 30);
		   j5.setBounds(80, 190, 200, 30);
		   j6.setBounds(80, 220, 200, 30);
		   j7.setBounds(80, 250, 200, 30);
		   j8.setBounds(80, 275, 200, 30);
		   j9.setBounds(80, 290, 200, 30);
		   j10.setBounds(80, 315, 200, 30);
		   j11.setBounds(80, 345, 200, 30);
		   j12.setBounds(80, 390, 200, 30);
		   */
		
		

		  
			
			f.setLayout(new GridLayout(14,2));
			g.add(r1);
			g.add(r2);
			f.getContentPane().add(r1);
			f.getContentPane().add(r2);
			
		//r1.setBounds(80, 315, 200, 30);
		//r2.set 
		f.add(j1);
		f.add(t1);
		f.add(j2);
		f.add(t2);
		f.add(j3);
		f.add(datePicker);
		f.add(j4);
		f.add(r1);
		f.add(new JLabel(" "));
		f.add(r2);

		f.add(j5);
		f.add(t4);
		f.add(j6);
		f.add(t5);
		f.add(j7);
		f.add(t6);
		f.add(j8);
		f.add(t7);
		f.add(j9);
		f.add(t8);
		f.add(j10);
		f.add(t9);
		f.add(j11);
		f.add(p1);
		f.add(j12);
		
		f.add(p2);
		  f.add(btn1);
	       f.add(btn2);
		
	//	 t1.addActionListener(this);
	   //  t2.addActionListener(this);
	     btn1.addActionListener(this);
	        btn2.addActionListener(this);
	 /*    tf5.addActionListener(this);
	     tf6.addActionListener(this);
	     tf7.addActionListener(this);
	     btn1.addActionListener(this);
	     btn2.addActionListener(this);
	     p1.addActionListener(this);
	     p2.addActionListener(this);*/
	    
	    
 }

public static void main(String args[])
{
	new validation();

}

@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	
	 Date selectedDate = (Date) datePicker.getModel().getValue();
	  Calendar cal=Calendar.getInstance();
		
	  cal.setTime(selectedDate);
	if(e.getSource()==btn1){
		
		String tx1=t1.getText();
		String tx2=t2.getText();
	String tx4=t4.getText();
	String tx5=t5.getText();
	String tx6=t6.getText();
	String tx7=t7.getText();
	String tx8=t8.getText();	
	String tx9=t9.getText();	
	char[] pwd = p1.getPassword();
	char[] pwd2 = p2.getPassword();
	String p1=new String(pwd);
	String p2=new String(pwd2);
	System.out.println(p1+"  "+p2);

		
		
		    int syear =cal.get( Calendar.YEAR);
	int  smonth=cal.get(Calendar.MONTH)+1;
	int sday=cal.get(Calendar.DAY_OF_MONTH);
		    System.out.println(smonth);
	
		Calendar now = Calendar.getInstance();
		int year = now.get(Calendar.YEAR);
		int month = now.get(Calendar.MONTH) + 1;
		int day=now.get(Calendar.DAY_OF_MONTH);
		int age=year-syear;
	
		if(smonth>month){
			age--;
		}
		else if(smonth==month){
			if(sday>day){
				age--;
			}
			
		}
		if(!((tx1.length()>=2 || tx1.length()<=20)  && tx1.matches("^[a-zA-Z][a-zA-Z][a-zA-Z0-9]*$"))){
			JOptionPane.showMessageDialog(null,"Min-2and max-20 characters. First 2-charccters should be alphabets");
		}
		if(!(tx2.length()>=2 || tx2.length()<=20)){
			JOptionPane.showMessageDialog(null,"Min-2and max-20 characters");
		}
		if(!(age>18)){
			JOptionPane.showMessageDialog(null,"age should b >18");
		}
		
		if((r1.isSelected()==false)&&(r2.isSelected()==false)){
			JOptionPane.showMessageDialog(null,"Please select radio button");
			}
		if(tx4.equals("") || tx5.equals("") || tx6.equals("")){
			JOptionPane.showMessageDialog(null,"Please enter max of 30 charac");
		}
		if(!(tx8.matches("^[0-9]*$") && tx8.length()==10)){
			JOptionPane.showMessageDialog(null,"Ph no 10 digit no only");
		}
		
		if(!(tx7.matches("^[a-zA-Z0-9]*$") && tx7.length()==6)){
			JOptionPane.showMessageDialog(null,"pincode Must be 6-charcters. Alpha numeric.");	
		}
		if(!(tx8.matches("^[0-9]*$") && tx8.length()==10))
		
		System.out.println("age:"+age+ "     " +r1.isSelected()+"  "+tx4+  "    "+tx7);
   if(!tx9.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,6}$")){
	   JOptionPane.showMessageDialog(null,"enter a valid email address");	
   }
	
   if(!(tx7.matches("^[a-zA-Z0-9]*$") && tx7.length()==6)){	
	   JOptionPane.showMessageDialog(null,"pin code Must be 6-charcters. Alpha nume");	
   }
   if(!(p1.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#`.``_``-`$%^&+=])[?=\\S+$]{6,12}$") && p1.equals(p2))){
	   JOptionPane.showMessageDialog(null,"condition not sati password");	
   }
		
   
   
   
   
		if((tx1.length()>=2 || tx1.length()<=20)  && tx1.matches("^[a-zA-Z][a--zAZ][a-zA-Z0-9]*$")){
		 
	if(tx2.length()>=2 || tx2.length()<=20){
		System.out.println("1 passed");
		if(age>18){
			System.out.println("age passed");
			if((r1.isSelected()==true) || (r2.isSelected()==true)){
				System.out.println("radio passed");
			if(tx4.length()<=30 || tx5.length()<=30 || tx6.length()<=30){
				System.out.println("street city apssed");
				if(tx7.matches("^[a-zA-Z0-9]*$") && tx7.length()==6){	
					System.out.println("pin passed");
				if(tx8.matches("^[0-9]*$") && tx8.length()==10){
					System.out.println("phno passed");
					if(tx9.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,6}$")){
						System.out.println("mail passed");
						if(p1.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#`.``_``-`$%^&+=])[?=\\S+$]{6,12}$") && p1.equals(p2)){
	JOptionPane.showMessageDialog(null,"success");
	System.out.println("pass passed");
	
	}
					}}}}}}}
	

		}}
	
	if(e.getSource()==btn2){
		t1.setText("");
		t2.setText("");
		t4.setText("");
		t5.setText("");
		t6.setText("");
		t7.setText("");
		t8.setText("");
		t9.setText("");
		p1.setText("");
		t2.setText("");
		p2.setText("");
	g.clearSelection();
	datePicker.getModel().setValue(null);;
	
		
	}

}



}



