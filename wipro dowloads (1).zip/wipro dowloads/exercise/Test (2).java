package com.automobile.TwoWheeler;
import java.io.*;
import java.util.*;
import java.lang.*;
import com.automobile.FourWheeler.*;

public class Test {

	public static void main(String[] args) {
		Hero h=new Hero("cc250","T353","RAJA",70);
		Honda ho=new Honda("k7","T454","RANI",50);
		Logan l=new Logan("alto","TN8k143","Nithya",180);
		Ford  f=new Ford("figo","AP9k111","Sindhu",100);
		
		System.out.println("Hero:" + " " + h.getModelName() +" "+h.getOwnerName()+" "+h.getRegistrationNumber()+" "+h.getSpeed());
		h.radio();
 System.out.println("Honda:" + " " + ho.getModelName() +" "+ho.getOwnerName()+" "+ho.getRegistrationNumber()+" "+ho.getSpeed());
 ho.cdplayer();
 
 System.out.println("LOGAN:" + " " + l.getModelName() +" "+l.getOwnerName()+" "+l.getRegistrationNumber()+" "+l.getSpeed());
 l.gps();
 System.out.println("Ford:" + " " + f.getModelName() +" "+f.getOwnerName()+" "+f.getRegistrationNumber()+" "+f.getSpeed());
 f.tempControl();
	}

}
