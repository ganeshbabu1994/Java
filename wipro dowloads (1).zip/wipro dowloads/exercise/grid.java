package swing;

import java.awt.GridLayout;
import java.util.Scanner;

import javax.swing.*;

public class grid extends JFrame {
	   public static void main(String[] args) {
		   Scanner in=new Scanner(System.in);
		   int row=in.nextInt();
		   int col=in.nextInt();
		   JFrame f=new JFrame();
		   JPanel jp=new JPanel();
		   jp.setLayout(new GridLayout(row,col));
		   JButton b[][]=new JButton[row][col];
		   for(int i=0;i<row;i++){
			   for (int j=0;j<col;j++){
				   b[i][j]=new JButton("awt");
				   jp.add(b[i][j]);
			   }
		   }
		   
		   f.setSize(200,200);
			
		   f.setVisible(true);
		   f.getContentPane().add(jp);
		   
			
	   }
	   

}
