package com.wipro.pos.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import com.wipro.pos.bean.FoodBean;
import com.wipro.pos.dao.AdministratorDAO;
import com.wipro.pos.util.DBUtil;

public class viewAll_pizza extends JFrame {
		Connection con1=DBUtil.getDBConnection();
		PreparedStatement pst;
		static JFrame f=new JFrame();
		String ps="",ptype="";
		static JTable table;
		
		
		JPanel p1=new JPanel();
		
			JScrollPane scroll;
			
		AdministratorDAO ad=new AdministratorDAO();
		FoodBean fbean=new FoodBean();
		ArrayList<FoodBean> al=new ArrayList<FoodBean>();
		String[] column={"foodId","Name","Type","food size","quantity","price"};
		viewAll_pizza(){
			
			f.setLayout(new FlowLayout());
				 DefaultTableModel model = new DefaultTableModel();
			        model.setColumnIdentifiers(column);
			        table = new JTable();
			        table.setModel(model);
			       table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
			       table.setBackground(Color.WHITE);
			       Border border = LineBorder.createGrayLineBorder();
				table.setBorder(border);
			        table.setFillsViewportHeight(true);
			        scroll = new JScrollPane(table);
			       scroll.setHorizontalScrollBarPolicy(
			              JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			        scroll.setVerticalScrollBarPolicy(
			               JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			        al=ad.viewAllFood();
					Iterator a=al.iterator();
					while(a.hasNext())
					{
					    FoodBean fb1=(FoodBean)(a.next());
					    if(fb1.getType().equals("Veg")){
							 ps="Veg";
							}
							else {
								ps="Non-Veg";
							}
					    	

							if(fb1.getFoodSize().equals("Small")){
								 ptype="Small";
							}
							else if(fb1.getFoodSize().equals("Medium")){
								ptype="Medium";
							}
							else {
								 ptype="Large";
							}
					    model.addRow(new Object[]{fb1.getFoodId(),fb1.getName(),ps, ptype, fb1.getQuantity(),fb1.getPrice()});

					   }
					table.setEnabled(false);
			p1.add(scroll);
				
				f.getContentPane().add(p1);
				//p1.setSize(400, 300);
			//table.setBounds(4,100,500,200);
				 setTitle("JDBC DEMO");
			       f.setBackground(Color.WHITE);
				
				f.setVisible(true);
			   p1.validate();
			      //  f1.setLayout(null);
			      
		}
		public static void main(String arg[])
		   {
		   
		  new viewAll_pizza();
		
			
		   }
}
