import java.util.*;
import java.lang.*;
import java.io.*;
class Author{
private String name;
private String email;
private char gender;
Author(String name,String email,char gender){
this.name=name;
this.email=email;
this.gender=gender;
}

public void setName(String name){
this.name=name;

}

public void setEmail(String email){
this.email=email;

}
public void setGender(char gender){
this.gender=gender;

}

public String getName(){
return (this.name);
}

public String getEmail(){
return (this.email);
}


public char getGender(){
return (this.gender);
}

public String toString(){

return (this.getName()+"\t"+this.getEmail()+"\t"+this.getGender());
}


}
class Book{
private String name;
private Author author;
private double price;
private int qtyInStock;
Book(String name,Author author,double price,int qty ){
this.name=name;
this.author=author;
this.price=price;
this.qtyInStock=qty;
}




public void setPrice(double price){
this.price=price;

}


public void setQtyInStock(int qty){
this.qtyInStock=qty;
}

public String getName(){
return (this.name);
}

public Author getAuthor(){
return (this.author);
}

public double getPrice(){
return (this.price);
}

public int getQtyInStock(){
return (this.qtyInStock);
}
public String toString(){

return(this.getName()+"\t"+this.getPrice()+"\t"+this.getQtyInStock()+"\t"+author);

}

public static void main(String args[]){
Author author=new Author("Chetan Baghat","Chetan@gmail.com",'M');

Book aBook=new Book("Two States",author,130,10);

System.out.println("BOOK"+"   \t"+"     price"+"\t"+"  quantity"+"\t"+"  author"+"\t"+"   email"+"\t"+"  gender"+"\n");
System.out.print(aBook);
}


}