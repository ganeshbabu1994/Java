import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;


public class Event5 extends JFrame {
	//JLabel l;
	public Event5()
	{		
		addWindowListener(new Mouse (this));

	//	l=new JLabel(" ");
	//	add(l);
	
	}
	class Mouse extends WindowAdapter
	{
		Event5 e;
		public Mouse(Event5 e)
		{
			this.e=e;
		
		}
	

	
	

	
public void WindowClosing(WindowEvent me){
	//l.setText("mouse clicked at:" +me.getClickCount());
	System.exit(0);
}
	}
	public static void main(String[] args) {
Event5 obj=new Event5();
obj.setVisible(true);
	}
}	