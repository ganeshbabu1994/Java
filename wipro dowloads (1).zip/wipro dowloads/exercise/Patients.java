import java.util.*;
import java.lang.*;
import java.io.*;
class patient{
private String name;
private double h,w;
public double bbmi;
public void setName(String na){
this.name=na;

}

public void setH(double h){
this.h=h;

}
public void setW(double w){
this.w=w;

}

public String getName(){
return name;
}


public double getH(){
return h;
}
public double getW()
{
return w;
}
public double BMI()
{
bbmi=((w*2.2046)/((h*0.393790)*(h*0.393790)))*703;
return bbmi;
}
public String toString(){

if(BMI()>25){
return (this.getName()+"\t\t"+String.format("%.2f",this.h)+"\t"+String.format("%.2f",this.w)+"  \t"+"over weight"+"\t"+String.format("%.2f",BMI())+"\n");
}
else
return(" ");

}

}
public class Patients{

public static void main(String args[]){
patient p[]=new patient[10];

for(int i=0;i<10;i++){
p[i]=new patient();
}
p[0].setName("Nithya");

p[1].setName("sindhu");
p[2].setName("ganesh");
p[3].setName("ramesh");
p[4].setName("anushya");
p[5].setName("shalini");
p[6].setName("gaja");
p[7].setName("anjel");
p[8].setName("yazhini");
p[9].setName("loga");



for(int i=0;i<10;i++){
p[i].setH((double)(Math.random()*100));
p[i].setW((double)(Math.random()*100));

}
System.out.println("PatientName"+"\t"+"height"+"\t"+"weight"+"\t"+"BMI\n");
for(int i=0;i<10;i++){
System.out.println(p[i].toString());
}
}
}