import java.util.*;
import java.io.*;
import java.lang.*;

 
class RandomHelper{
 static  int a;
static double b;
static public int randint(int max,int min){
a=(int) ((Math.random()*((max+1)-(min)))+(min));
return a;
}


static public double randdouble(double max,double min){
b=(double) ((Math.random()*(max-(min)))+(min));
return b;
}




}
class Randomno{

public static void main(String args[]){

System.out.println(RandomHelper.randint(10,1));
System.out.println(String.format("%.2f",RandomHelper.randdouble(10,1)));

}
}