
public class dataTypeSize {

	public static void main(String[] args) {
int minintval=Integer.MIN_VALUE;
int maxintval=Integer.MAX_VALUE;
float minfloatval=Float.MIN_VALUE;
float maxfloatval=Float.MAX_VALUE;
short minshortval=Short.MIN_VALUE;
short maxshortval=Short.MAX_VALUE;
byte minbyteval=Byte.MIN_VALUE;
byte maxbyteval=Byte.MAX_VALUE;
long minlongval=Long.MIN_VALUE;
long maxlongval=Long.MAX_VALUE;
double maxdouble=Double.MAX_VALUE;
double mindouble=Double.MIN_VALUE;
System.out.println("Integer range\n"+"Minvalue:"+minintval+"\nmaxvalue:"+maxintval);
System.out.println("Double range\n"+"Minvalue:"+mindouble+"\nmaxvalue:"+maxdouble);
System.out.println("Long range\n"+"Minvalue:"+minlongval+"\nmaxvalue:"+maxlongval);
System.out.println("Short range\n"+"Minvalue:"+minshortval+"\nmaxvalue:"+maxshortval);
System.out.println("float range\n"+"Minvalue:"+minfloatval+"\nmaxvalue:"+maxfloatval);
System.out.println("byte range\n"+"Minvalue:"+minbyteval+"\nmaxvalue:"+maxbyteval);
	}

}
