package com.automobile.FourWheeler;
import com.automobile.*;
public class Ford extends Vehicle {
	int speed;
	public Ford(String mname,String regno,String oname,int speed)
	{
		
		super(mname,regno,oname);
		this.speed=speed;
	}
public String getModelName(){
	return super.modelName;
}
public String getRegistrationNumber()
{
	return super.regno;
}
public String getOwnerName()
{
	return super.ownername;
}
public int getSpeed()
{
	return this.speed;
}
public void tempControl()
{
	System.out.println("this model provides ac control facility");
}
}
