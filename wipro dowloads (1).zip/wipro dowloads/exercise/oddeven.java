
class printno{
	 int i=1;
public synchronized void print(String name) throws InterruptedException{
if(name.equals("threadodd")){
	if(i%2==1){
		System.out.println(i++);
		notify();
	}
	else{
		wait();
	}
	
}	
else if(name.equals("threadeven")){
	if(i%2==0){
		System.out.println(i++);
		notify();
	}
	else{
		wait();
	}
	
}	


}
}
class ee extends Thread{
printno s;	
Thread t;
String name;
            ee(printno s,String name){
	this.s=s;
	t=new Thread(this);

	this.name=name;
	t.setName(name);
	t.start();
	}
	public void run(){
		while(s.i<=10){
			try {
				s.print(Thread.currentThread().getName());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
}}
public class oddeven {

    public static void main(String[] args){
    	 printno p=new printno();
    ee e=new ee(p,"threadodd");
    ee e1=new ee(p,"threadeven");
    	
    	
    	
    	
      
    }}