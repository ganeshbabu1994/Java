package com.wipro;

public class Fibbonacci
{

	public int nthFibonacci(int num)    
	{
	if(num==1)
	  {   
           return 0;
      }
	 if(num==2)
	 {
		 return 1;
     }
	 return nthFibonacci(num-1)+nthFibonacci(num-2);
	 }
}