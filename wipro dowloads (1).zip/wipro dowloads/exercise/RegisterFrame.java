package com.wipro.ata.ui;


import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.jdatepicker.impl.DateComponentFormatter;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import com.wipro.ata.bean.ProfileBean;
import com.wipro.ata.listener.RegisterListener;




public class RegisterFrame extends JFrame implements ActionListener{
	JTextField t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12;
	JPasswordField pf1;
	JButton b;
	Container con;
	JFrame f1;
	JPanel p1,p2;
	JLabel l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13;
	UtilDateModel model = new UtilDateModel();
	Properties p=new Properties();
	JDatePanelImpl datePanel = new JDatePanelImpl(model,p);
	JDatePickerImpl datePicker = new JDatePickerImpl(datePanel,new DateComponentFormatter());
	
	ProfileBean pb=new ProfileBean();
	RegisterFrame()
	{
		con=getContentPane();
		f1=new JFrame("Register");
		f1.setSize(700,700);
		f1.setLocation(200,80);
		f1.setLayout(new BorderLayout());
		f1.setVisible(true);
		p1=new JPanel();
		p2=new JPanel();
		l2=new JLabel("firstName");
		t2=new JTextField(10);
		l3=new JLabel("lastName");
		t3=new JTextField(10);
		l4=new JLabel("dateOfBirth");
		l5=new JLabel("gender");
		t5=new JTextField(10);
		l6=new JLabel("Street");
		t6=new JTextField(10);
		l7=new JLabel("location");
		t7=new JTextField(10);
		l8=new JLabel("city");
		t8=new JTextField(10);
		l9=new JLabel("State");
		t9=new JTextField(10);
		l10=new JLabel("pincode");
		t10=new JTextField(10);
		l11=new JLabel("mobileNo");
		t11=new JTextField(10);
		l12=new JLabel("emailId");
		t12=new JTextField(10);
		l13=new JLabel("password");
		pf1=new JPasswordField(10);
		b=new JButton("SUBMIT");
		p1.setLayout(new GridLayout(0,2));
		p1.add(l2);
		p1.add(t2);
		p1.add(l3);
		p1.add(t3);
		p1.add(l4);
		p1.add(datePicker);
		p1.add(l5);
		p1.add(t5);
		p1.add(l6);
		p1.add(t6);
		p1.add(l7);
		p1.add(t7);
		p1.add(l8);
		p1.add(t8);
		p1.add(l9);
		p1.add(t9);
		p1.add(l10);
		p1.add(t10);
		p1.add(l11);
		p1.add(t11);
		p1.add(l12);
		p1.add(t12);
		p1.add(l13);
		p1.add(pf1);
		p2.add(b);
		b.addActionListener(this);
		f1.getContentPane().add(p1,BorderLayout.CENTER);
		f1.getContentPane().add(p2,BorderLayout.SOUTH);
		
		
		
	}
	
	

	public static void main(String[] args) {
		RegisterFrame r=new RegisterFrame();
		
	}



	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b)
		{
			
			pb.setFirstName(t2.getText());
			pb.setLastName(t3.getText());
			//pb.setDateOfBirth(datePicker.getJFormattedTextField().getText());
			
			
			pb.setGender(t5.getText());
			pb.setStreet(t6.getText());
			pb.setLocation(t7.getText());
			pb.setCity(t8.getText());
			pb.setState(t9.getText());
			pb.setPincode(t10.getText());
			if(t11.getText().length()==10)
			{
			pb.setMobileNo(t11.getText());
			}else
			{
				JOptionPane.showMessageDialog(null, "Enter 10 digit Mobile number");
				t11.setText("");
			}
			System.out.println();
			pb.setEmailID(t12.getText());
			pb.setPassword(pf1.getText());
			String s=new RegisterListener().register(pb);
			if(s=="FAIL")
			{
				JOptionPane.showMessageDialog(null,"Error during Registration");
			}else
			{
				JOptionPane.showMessageDialog(null,"Registration success, UserID: "+s);
			}
			
		}
		
	}

}