class video{
private String title;
private boolean checkout;
private int avg;
private int count=0;
private int countno=0;
public void setCount(int count)
{
this.count=count;
}
public void setCountno(int countno)
{
this.countno=countno;
}

public int getCount(){
return this.count;
}

public int getCountno(){
return this.countno;
}


public void setTitle(String title)
{
this.title=title;
}

public void setCheckout(boolean checkout)
{
this.checkout=checkout;
}

public void setAvg(int avgrating)
{
this.avg=avgrating;
}

public String getTitle()
{
return this.title;
}

public boolean isCheckout()
{
return this.checkout;
}

public int getAvg()
{
return this.avg;
}



public boolean beingReturned(){

if(this.isCheckout())
{
return false;
}
else
return true;
}





}




class VideoStore {


public void addVideo(String vname,video v[]){
for(int i=0;i<=9;i++){
if((v[i].getTitle()).equals("0") && !((v[i].getTitle()).equals(vname)) ){
v[i].setTitle(vname);
break;
}

}}

public void checkOutvideo(String vname,video v[]){


for(int i=0;i<=9;i++){
if((v[i].getTitle()).equals(vname))
{
v[i].setCheckout(true);
break;
}

}
 
}


public void returnVideo(String vname,video v[]){

for(int i=0;i<=9;i++){
if((v[i].getTitle()).equals(vname) ){

v[i].setCheckout(false);
}

}}


public  void receiveRating(String vname,int rate,video v[]){
  
 int no=0,cno=0,k=0;

for(int i=0;i<=9;i++){
if((v[i].getTitle()).equals(vname) ){
k=i;
no=v[i].getCount()+rate;
cno=v[i].getCountno()+1;
}
}
v[k].setCount(no);
v[k].setCountno(cno);

v[k].setAvg((v[k].getCount()/v[k].getCountno()));


}



public void listInventory(video v[]){

for(int i=0;i<=9;i++){
if((v[i].isCheckout())==false && !((v[i].getTitle()).equals("0")))

System.out.println(v[i].getTitle()+"\t"+v[i].isCheckout()+"\t"+v[i].getAvg());

}
} 

}












public class VideoStorelaunch {

public static void main(String args[]){

video v[]=new video[10];
VideoStore vs=new VideoStore();
for(int i=0;i<=9;i++){
v[i]=new video();
v[i].setTitle("0");
}

v[0].setTitle("The Matrix");
v[1].setTitle("Godfather II");

v[0].setCheckout(false);
v[1].setCheckout(false);
v[2].setCheckout(false);
v[3].setCheckout(false);
v[4].setCheckout(false);
v[5].setCheckout(false);




vs.addVideo("A New Hope:",v);
vs.addVideo("Star Wars Episode IV",v);
vs.addVideo("Two States",v);
vs.addVideo("Ramayanam",v);



vs.checkOutvideo("A New Hope:",v);
vs.checkOutvideo("Star Wars Episode IV",v);
vs.checkOutvideo("Ramayanam",v);



vs.returnVideo("A New Hope:",v);
vs.returnVideo("Star Wars Episode IV",v);
vs.returnVideo("Ramayanam",v);


vs.receiveRating("The Matrix",3,v);
vs.receiveRating("The Matrix",5,v);

vs.receiveRating("Godfather II",5,v);
vs.receiveRating("Godfather II",5,v);

vs.receiveRating("The Matrix",3,v);
vs.receiveRating("The Matrix",5,v);

vs.receiveRating("Star Wars Episode IV",3,v);
vs.receiveRating("Star Wars Episode IV",2,v);
vs.receiveRating("Godfather II",5,v);
vs.receiveRating("Godfather II",5,v);

vs.receiveRating("Two States",3,v);
vs.receiveRating("Two States",5,v);

vs.receiveRating("Two States",5,v);
vs.receiveRating("Star Wars Episode IV",1,v);

vs.receiveRating("Ramayanam",10,v);
vs.receiveRating("Ramayanam",10,v);
vs.receiveRating("Two States",6,v);
vs.receiveRating("Two States",7,v);

vs.listInventory(v);


}
}