package gaju;

import java.util.*;
import java.io.*;
public class Ve {


	public static void main(String[] args) throws IOException, ClassNotFoundException
	{
		Vector obj=new Vector();
int a=Integer.parseInt(args[0]);
int b=Integer.parseInt(args[1]);
int c=Integer.parseInt(args[2]);

obj.add(args[0]);  
obj.add(args[1]);
obj.add(args[2]);
FileOutputStream out=new FileOutputStream("Date");
ObjectOutputStream s=new ObjectOutputStream(out);
FileInputStream in=new FileInputStream("Date");
ObjectInputStream v=new ObjectInputStream(in);
s.writeObject(obj);
obj.add(v.readObject());
Iterator t=obj.iterator();
while(t.hasNext())
{
	System.out.println(t.next());
}





	}







	}


