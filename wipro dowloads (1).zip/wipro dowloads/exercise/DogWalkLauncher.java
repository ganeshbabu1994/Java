import java.util.*;
import java.lang.*;
import java.io.*;
import java.text.*;

class Dog{
SimpleDateFormat sdfDate = new SimpleDateFormat("hh");
    Date d = new Date();
    String strDate = sdfDate.format(d);
 

 int a;
a=Integer.parseInt(strDate);
 System.out.println(a);

//public double ct=1.30;
 private int drinkTime;
 Dog(int time){
this.drinkTime=time;
}

public void setDrinkTime(int d){
this.drinkTime=d;
}

public int getDrinkTime( ){
return (this.drinkTime);
}

public boolean needsToGo(){
 
if((d1-this.drinkTime)>4){
return true;

}
else 
return false;

}

}

class DogOwner{
public boolean takeForWalk(Dog d){
if(d.needsToGo()){
return true;
}

else
return false;

}

}




public class DogWalkLauncher{
public static void main(String args[]){
Dog d=new Dog(4);
DogOwner dow=new DogOwner();
System.out.println("testDogWalk1:"+d.needsToGo());
System.out.println("testDogWalk2:"+dow.takeForWalk(d));
}
}