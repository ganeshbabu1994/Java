import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class Charcount {
	public static void main (String args[ ]) throws IOException {
		File input=new File("1.txt");
		
		FileReader inreader=new FileReader(input);
		
		int c,count=0;
		char c1;
		do {
		c =inreader.read();
		c1=(char)(c);
		if(c1==args[0].charAt(0)){
			count++;
		}
		}while (c!=-1);
		System.out.println(count);
		inreader.close();
		
		}
		
}
