package swing;



import java.awt.*;

import javax.swing.*;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.plaf.basic.BasicBorders.RadioButtonBorder;

import org.jdatepicker.impl.*;

import java.net.PasswordAuthentication;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.lang.*;

//import swing.DateLabelFormatter;

public class xxx extends JFrame
{



public static void main(String args[])
{
	JFrame f=new JFrame();
	f.setVisible(true);
	f.setSize(300, 300);
	JLabel j1,j2,j3,j4,j5,j6,j7,j8,j9,j10,j11,j12;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11;
	
	UtilDateModel model = new UtilDateModel();
	Properties p = new Properties();
	p.put("text.today", "Today");
	p.put("text.month", "Month");
	p.put("text.year", "Year");
	JDatePanelImpl datePanel = new JDatePanelImpl(model,p);
	JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateComponentFormatter());
	
	 
	

	JPasswordField p1=new JPasswordField(20);
	JPasswordField p2=new JPasswordField(20);
	j1=new JLabel("First name");
	j2=new JLabel("Last name");
	j3=new JLabel("DOB");
	
	j4=new JLabel("Gender");
	j5=new JLabel("Street");
	j6=new JLabel("City");
	j7=new JLabel("State");
	j8=new JLabel("Pincode");
	j9=new JLabel("mobile number");
	j10=new JLabel("EmailId");
	j11=new JLabel("password");
	j12=new JLabel("confirm password");
	
	t1=new JTextField(20);
	t2=new JTextField(20);
	t3=new JTextField(20);
	t4=new JTextField(20);
	t5=new JTextField(20);
	t6=new JTextField(20);
	t7=new JTextField(20);
	t8=new JTextField(20);
	t9=new JTextField(20);
	t10=new JPasswordField(20);
	t11=new JPasswordField(20);

	/*   j1.setBounds(80, 70, 200, 30);
	   j2.setBounds(80, 100, 200, 30);
	   j3.setBounds(80, 130, 200, 30);
	   j4.setBounds(80, 160, 200, 30);
	   j5.setBounds(80, 190, 200, 30);
	   j6.setBounds(80, 220, 200, 30);
	   j7.setBounds(80, 250, 200, 30);
	   j8.setBounds(80, 275, 200, 30);
	   j9.setBounds(80, 290, 200, 30);
	   j10.setBounds(80, 315, 200, 30);
	   j11.setBounds(80, 345, 200, 30);
	   j12.setBounds(80, 390, 200, 30);
	   */
	
	

	   JRadioButton r1=new JRadioButton("Male",true);
		JRadioButton r2=new JRadioButton("Female");
		ButtonGroup g =new ButtonGroup();
		f.setLayout(new GridLayout(13,2));
		g.add(r1);
		g.add(r2);
		f.getContentPane().add(r1);
		f.getContentPane().add(r2);
		
	//r1.setBounds(80, 315, 200, 30);
	//r2.set 
	f.add(j1);
	f.add(t1);
	f.add(j2);
	f.add(t2);
	f.add(j3);
	f.add(datePicker);
	f.add(j4);
	f.add(r1);
	f.add(new JLabel(" "));
	f.add(r2);

	f.add(j5);
	f.add(t4);
	f.add(j6);
	f.add(t5);
	f.add(j7);
	f.add(t6);
	f.add(j8);
	f.add(t7);
	f.add(j9);
	f.add(t8);
	f.add(j10);
	f.add(t9);
	f.add(j11);
	f.add(p1);
	f.add(j12);
	
	f.add(p2);
	
	

}
}

class DateLabelFormatter extends AbstractFormatter {
	 
    private String datePattern = "yyyy-MM-dd";
    private SimpleDateFormat dateFormatter = new SimpleDateFormat(datePattern);
     
    @Override
    public Object stringToValue(String text) throws ParseException {
        return dateFormatter.parseObject(text);
    }
 
    @Override
    public String valueToString(Object value) throws ParseException {
        if (value != null) {
            Calendar cal = (Calendar) value;
            return dateFormatter.format(cal.getTime());
        }
         
        return "";
    }
 
}
