package com.wipro;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Simputer {
	
	//function1 // do not change the data types 
	byte add( byte b1 , byte b2)
	{
		return(byte)(b1+b2);
	}
	//function2// do not change the data types 
	short add( short b1 , short b2)
	{
		return(short)(b1+b2);
	}
	 //function3 // do not change the data types 
	static int[] print_binary(byte number)
	{
		int[] result;
		int size=10;
		if( number< 16) 
			result= new int[4];
		else if(number< 32 )
			result= new int[5];
		else if(number< 64)
			result= new int[6];
		else result= new int[7];
		int i=0;
		for( i=0; number>0; i++)	
		{
			result[i]=number%2;
		  
		   number=(byte)(number/(byte)2);  
	     }
		return result;
	}
	@Test
	public void test_print_binary() 
	{
		int res1[] = {0,1,0,1};
		assertArrayEquals(res1, Simputer.print_binary((byte)10));
		res1 = new int[] {1,1,0,1};
		assertArrayEquals(res1, Simputer.print_binary((byte)11));
	}
	
	@Test
	public void Testadd()
	{
		Simputer s=new Simputer();
		assertEquals((byte)5,s.add((byte)2, (byte)3));
	}
	
	
	@Test
	public void Testadd1()
	{
		Simputer s=new Simputer();
		assertEquals((short)30,s.add((short)10, (short)20));
	}
	
}


