package com.wipro;

import static org.junit.Assert.*;

import org.junit.Test;

public class CubeTest {

	@Test
	public void testIsCube() {
		Cube c=new Cube();
		
		assertEquals(false,c.isCube(4));
		assertEquals(true,c.isCube(125));
		assertEquals(true,c.isCube(27));
	}

}
