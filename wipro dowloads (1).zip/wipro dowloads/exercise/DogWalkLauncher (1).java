class Dog
{
	public int time;
	public int dtime;
	Dog(int time, int dtime)
	{	
		this.time = time;	
		this.dtime = dtime;
	}	
	public void setTime(int time)
	{
		this.time = time;
	}
	public void setDrinkTime(int dtime )
	{
		this.dtime = dtime;
	}
	public int getTime()
	{
		return this.time;
	}
	public int getDrinkTime()
	{
		return this.dtime;
	}
	
	public boolean needsToGo()
	{
		if((this.time-this.dtime)>4)
		{
			return true; 
		}
		else
		{
			return false;
		}
	
	}
}

class DogOwner 
{
	public boolean takeForWalk(Dog d)
	{
		if(d.needsToGo())
		{
			return true;	
		}
		else
		{
			return false;
		}
	}
}

class DogWalkLauncher
{
	public static void main(String args[])
	{
		Dog obj1 = new Dog(12, 5);
		DogOwner obj2 = new DogOwner();
		System.out.println("testDogWalk1: "+obj1.needsToGo());	
		System.out.println("testDogWalk2: "+obj2.takeForWalk(obj1));	
	}
}